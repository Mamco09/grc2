<!DOCTYPE html>
<html>
  <head>
    <!-- les meta données -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <title>GRC (Connexion)</title>

    <!-- Lien vers le fichier bootstrap -->
    <link rel="stylesheet" href="utilisateur/css/bootstrap.min.css">
    <script defer src="utilisateur/js/solid.js"></script>
    <script defer src="utilisateur/js/fontawesome.js"></script>
  </head>

<body style="background-color: #bac1cc">
  <!-- contenu de la page -->
  <div class="container">
    <!-- la row -->
    <div class="row">
      <!-- une div de 5 colone sur bootstrap -->
      <div class="col-md-5 ml-auto mr-auto align-center card bg-info" style="margin-top: 200px;">
        <!-- form Debut -->
        <form action="connexion.php" method="POST">
          <!-- div > label + input :identifiant -->
          <br>
          <div class="form-group">
            <label for="identifiant"><i class="fa fa-user" aria-hidden="true"></i> Identifiant</label>
            <input type="text" class="form-control" id="identifiant" aria-describedby="emailHelp" placeholder="Identifiant..." name="identifiant">
          </div>
          <br>
          <!-- div > label + input :mot de passe -->
          <div class="form-group">
            <label for="mdp"><i class="fa fa-unlock-alt" aria-hidden="true"></i> Mot de passe</label>
            <input type="password" class="form-control" id="mdp" placeholder="Mot de passe..." name="mdp">
          </div>
          <!-- btn connexion -->
          <button type="submit" class="btn btn-primary" name="submit">Connexion </button>
          <!-- ligne separatrice -->
          <br><br>
        <!-- form fin -->
        </form>
      <!-- fin de div de 5 colone sur bootstrap  -->
      </div>
    <!-- fin row --> 
    </div>
    <!-- fin du contenu -->
  </div>

  <!-- jQuery en premier, puis Popper.js, puis Bootstrap JS -->
  <script src="utilisateur/js/jquery-3.3.1.slim.min.js"></script>
  <script src="utilisateur/js/popper.min.js"></script>
  <script src="utilisateur/js/bootstrap.min.js"></script>
</body>

</html>