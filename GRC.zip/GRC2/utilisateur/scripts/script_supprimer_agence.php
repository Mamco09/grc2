<?php
	include_once '../includes/fonctions.php';  
	if (isset($_GET['id'])) 
	{
        $id = $_GET['id'];
		// requet de suppression agence
    	$requet = "DELETE FROM agence WHERE ID_AG = {$id}";
		// execution de la requet
		$resultat = ExecuterRequetMisAJour($requet);

		// verification du resultat de la requet 
		if ($resultat) {
			// renvoie vers /gestion_agence.php
			// op_re = operation reussie
			header("Location: ../gestion_agence.php?msg=op_re");
		}
		else{
			// renvoie vers /gestion_agence.php
			// op_ec = operation echouer
			header("Location: ../gestion_agence.php?msg=op_ec");
		}
	}
?>