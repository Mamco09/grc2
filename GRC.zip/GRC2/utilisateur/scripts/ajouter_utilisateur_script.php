<?php
    session_start();
	include_once '../includes/fonctions.php';  
	if (isset($_POST['submit'])) 
	{
		// recuperations des infos envoyer par post method 
		$prenom = $_POST['prenom'];
		$nom = $_POST['nom'];
		$genre = $_POST['genre'];
		$tel = $_POST['tel'];
		$identifiant = $_POST['identifiant'];
		$mdp = $_POST['mdp'];
        $date = $_POST['date'];
        $agence = $_POST['agence'];
        $profil = $_POST['profil'];
        $date_ajout = date("Y-m-d H:i:s");
        $id_admin = $_SESSION['id']; 

		// requet de mis a jour utilisateur
		echo $requet = "INSERT INTO utilisateur(PRENOM_U, NOM_U, GENRE_U, TEL_U, DATE_NAISS_U, IDENTIFIANT_U, MDP_U, ID_AG, ID_PROFIL, DATE_AJOUT_U, ID_ADMIN) VALUES('{$prenom}', '{$nom}', '{$genre}', {$tel}, '{$date}', '{$identifiant}', '{$mdp}', {$agence}, {$profil}, '{$date_ajout}', {$id_admin})";
		// execution de la requet
		$resultat = ExecuterRequetMisAJour($requet);

		// verification du resultat de la requet 
		if ($resultat) {
			// renvoie vers /tout_les_utilisateur.php
			// op_re = operation reussie
			header("Location: ../tout_les_utilisateur.php?msg=op_re");
		}
		else{
			// renvoie vers /tout_les_utilisateur.php
			// op_ec = operation echouer
			header("Location: ../tout_les_utilisateur.php?msg=op_ec");
		}
	}
?>