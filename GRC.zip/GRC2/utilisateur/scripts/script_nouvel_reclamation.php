<?php
	include_once '../includes/fonctions.php';  
	if (isset($_POST['submit'])) 
	{
		// recuperation de l'id envoyer avec get method
		$id = $_GET['id'];

		// recuperations des infos envoyer par post method 
		$type = $_POST['type'];
		$priorite = $_POST['priorite'];
		$description = $_POST['description'];
		$infosComplementaire = $_POST['infosComplementaire'];
		if ($infosComplementaire == "") {
			$infosComplementaire = "AUCUNNE";
		}
		$document = $_FILES['document']['name'];
		$nom_document_temp = $_FILES['document']['tmp_name'];
		$date = date("Y-m-d H:i:s");
		$num_comp_cli = $_POST['num_comp_cli'];
		$tel_cli = $_POST['tel_cli'];
		
		if ($document != "" && $nom_document_temp != "") 
		{
			
			move_uploaded_file($nom_document_temp, "../doc/$document");
			$requet1 = "INSERT INTO piece_jointe(
				NOM_PJ, 
				ID_U, 
				DATE_AJOUT_PJ
			) 
			VALUES (
			'{$document}', 
			{$id}, 
			'{$date}'
			)";
			
			$resultat1 = ExecuterRequetMisAJour($requet1);
			if ($resultat1) 
			{
				$requet2 = "SELECT ID_PJ FROM piece_jointe WHERE NOM_PJ = '{$document}' AND ID_U = {$id} AND DATE_AJOUT_PJ = '{$date}'";
				$resultat2 = ExecuterRequetRecuperation($requet2);
				if ($resultat2) 
				{
					$requet3 = "INSERT INTO reclamation (ID_U, ID_TYPE, ID_ETAT, ID_PRI, ID_PJ, DESCRIPTION_REC, INFO_COMP_REC, DATE_REC, NUM_CLI, TEL_CLI) VALUES ({$id}, {$type}, 1, {$priorite}, {$resultat2['ID_PJ']}, '{$description}', '{$infosComplementaire}', '{$date}', '{$num_comp_cli}', {$tel_cli})";
					$resultat3 = ExecuterRequetMisAJour($requet3);
					if ($resultat3) 
					{
						header("Location: ../reclamation_en_attente.php?msg=op_re");
					}
					else
					{
						header("Location: ../reclamation_en_attente.php?msg=op_ec");
					}
				} 
			}
		}
		else
		{
			echo $requet3 = "INSERT INTO reclamation (
				ID_U, 
				ID_TYPE, 
				ID_ETAT, 
				ID_PRI, 
				ID_PJ,
				DESCRIPTION_REC, 
				INFO_COMP_REC, 
				DATE_REC, 
				NUM_CLI, 
				TEL_CLI
			) 
			VALUES (
				{$id}, 
				{$type}, 
				1, 
				{$priorite}, 
				1, 
				'{$description}', 
				'{$infosComplementaire}', 
				'{$date}', 
				'{$num_comp_cli}', 
				{$tel_cli})";

				
			$resultat3 = ExecuterRequetMisAJour($requet3);
			if ($resultat3) 
			{
				header("Location: ../reclamation_en_attente.php?msg=op_re");
			}
			else
			{
				header("Location: ../reclamation_en_attente.php?msg=op_ec");
			}
		}	
	}
?>