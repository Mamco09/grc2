<?php
	include_once '../includes/fonctions.php';  
	if (isset($_GET['id'])) {
		echo $id = $_GET['id'];
		$requet = "UPDATE reclamation SET ID_ETAT = 3 WHERE ID_REC = {$id}";
		$resultat = ExecuterRequetMisAJour($requet);
		if ($resultat) {
			header("Location: ../reclamation_repondu.php?msg=op_re");
		}
	}
?>