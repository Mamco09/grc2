<?php
	include_once '../includes/fonctions.php';  
	if (isset($_GET['id'])) 
	{
        $id = $_GET['id'];
		// requet de suppression client
        $requet = "DELETE FROM client WHERE ID_CLI = {$id}";
		// execution de la requet
		$resultat = ExecuterRequetMisAJour($requet);

		// verification du resultat de la requet 
		if ($resultat) {
			// renvoie vers /tout_les_client.php
			// op_re = operation reussie
			header("Location: ../tout_les_clients.php?msg=op_re");
		}
		else{
			// renvoie vers /tout_les_client.php
			// op_ec = operation echouer
			header("Location: ../tout_les_clients.php?msg=op_ec");
		}
	}
?>