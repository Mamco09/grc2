<?php
	include_once '../includes/fonctions_admin.php';  
	if (isset($_GET['id'])) 
	{
        $id = $_GET['id'];
		// requet de suppression admin
    	$requet = "DELETE FROM admin WHERE ID_ADMIN = {$id}";
		// execution de la requet
		$resultat = ExecuterRequetMisAJour($requet);

		// verification du resultat de la requet 
		if ($resultat) {
			// renvoie vers /tout_les_admin.php
			// op_re = operation reussie
			header("Location: ../tout_les_admin.php?msg=op_re");
		}
		else{
			// renvoie vers /tout_les_admin.php
			// op_ec = operation echouer
			header("Location: ../tout_les_admin.php?msg=op_ec");
		}
	}
?>