<?php  
	include_once '../includes/fonctions.php';
	if ( $_GET['page']) 
	{
		$recherche = $_POST['recherche'];
		if ($_GET['page'] == "reclamation_en_attente.php") 
		{
			
			header("Location: ../search_rec_en_attente.php?re=$recherche");
		} elseif ($_GET['page'] == "reclamation_repondu.php") 
		{
			
			header("Location: ../search_rec_rep.php?re=$recherche");
		}
	}
	
?>