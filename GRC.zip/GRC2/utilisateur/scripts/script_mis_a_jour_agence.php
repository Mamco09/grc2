<?php  
	include_once '../includes/fonctions.php';
	if (isset($_POST['submit'])) {
		$id = $_GET['id'];

		$nom = $_POST['nom'];
		$adress = $_POST['adress'];

		echo $requet = "UPDATE agence SET NOM_AG = '{$nom}', ADRESSE_AG = '{$adress}' WHERE ID_AG = {$id}";

		$resultat = ExecuterRequetMisAJour($requet);

		if ($resultat) {
			
			header("Location: ../gestion_agence.php?msg=op_re");
		}
	}
?>