<?php  
	include_once '../includes/fonctions.php';
	if (isset($_POST['submit'])) {
		$id = $_GET['id'];

		$nom = $_POST['nom'];

		echo $requet = "UPDATE type SET NOM_TYPE = '{$nom}' WHERE ID_TYPE = {$id}";

		$resultat = ExecuterRequetMisAJour($requet);

		if ($resultat) {
			
			header("Location: ../gestion_type.php?msg=op_re");
        }
        else{
			header( "Location: ../gestion_type.php?msg=op_ec");

        }
	}
