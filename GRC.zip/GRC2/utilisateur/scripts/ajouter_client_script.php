<?php
    session_start();
	include_once '../includes/fonctions.php';  
	if (isset($_POST['submit'])) 
	{
		// recuperations des infos envoyer par post method 
		$prenom = $_POST['prenom'];
		$nom = $_POST['nom'];
		$genre = $_POST['genre'];
		$tel = $_POST['tel'];
        $date = $_POST['date'];
        $num_compt = $_POST['num_compt'];

		// requet de mis a jour utilisateur
		echo $requet = "INSERT INTO client(PRENOM_CLI, NOM_CLI, GENRE_CLI, TEL_CLI, DATE_NAISS_CLI, NUM_COMPT_CLI) VALUES('{$prenom}', '{$nom}', '{$genre}', {$tel}, '{$date}', {$num_compt})";
		// execution de la requet
		$resultat = ExecuterRequetMisAJour($requet);

		// verification du resultat de la requet 
		if ($resultat) {
			// renvoie vers /tout_les_clients.php
			// op_re = operation reussie
			header("Location: ../tout_les_clients.php?msg=op_re");
		}
		else{
			// renvoie vers /tout_les_clients.php
			// op_ec = operation echouer
			header("Location: ../tout_les_clients.php?msg=op_ec");
		}
	}
?>