<?php
	include_once '../includes/fonctions.php';
	ob_start();
	session_start();
	if (isset($_POST['mod_user'])) 
	{
		// recuperation de l'id envoyer avec get method
		$id = $_GET['id'];

		// recuperations des infos envoyer par post method 
		$prenom = $_POST['prenom'];
		$nom = $_POST['nom'];
		$genre = $_POST['genre'];
		$tel = $_POST['tel'];
		$identifiant = $_POST['identifiant'];
		$mdp = $_POST['mdp'];
		$date = $_POST['date'];
		$agence = $_POST['agence'];
		$profil = $_POST['profil'];

		// requet de mis a jour admin
	 	$requet = "UPDATE utilisateur SET PRENOM_U = '{$prenom}', NOM_U = '{$nom}', GENRE_U = '{$genre}', TEL_U = {$tel}, IDENTIFIANT_U = '{$identifiant}', MDP_U = '{$mdp}', DATE_NAISS_U = '{$date}', ID_AG = {$agence}, ID_PROFIL = {$profil} WHERE ID_U = {$id}";
		
		// execution de la requet
		$resultat = ExecuterRequetMisAJour($requet);

		// verification du resultat de la requet 
		if ($resultat) {
			if($_SESSION['page_actuel'] == "profil.php"){
				header("Location: ../profil.php?msg=op_re");
			}
			else
				header( "Location: ../tout_les_utilisateur.php?msg=op_re");
		}
		else{
		// renvoie vers /index.php
		// op_ec = operation echouer
		if ($_SESSION['page_actuel'] == "profil.php") {
			header("Location: ../profil.php?msg=op_ec");
		} else
			header( "Location: ../tout_les_utilisateur.php?msg=op_ec");
		}
	}
?> 