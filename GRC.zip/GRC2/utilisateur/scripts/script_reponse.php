<?php
	session_start();
	include_once '../includes/fonctions.php';  
	if (isset($_POST['submit'])) 
	{
		// recuperation de l'id envoyer avec get method
		$id_rec = $_GET['id_rec'];
		// recuperation de l'id de l'utilisateur actuel
		$id_u = $_SESSION['id'];
		// recuperations des infos envoyer par post method 
		
		$document = $_FILES['document']['name'];
		$nom_document_temp = $_FILES['document']['tmp_name'];
		$date = date("Y-m-d H:i:s");
		$reponse = $_POST['reponse'];
		// cas ou le document est vide 
		if ($document != "" && $nom_document_temp != "") 
		{
			// deplacement du fichier dans utilisateur/doc
			move_uploaded_file($nom_document_temp, "../doc/$document");
			// requet 1
			$requet1 = "INSERT INTO piece_jointe(
				NOM_PJ, 
				ID_U, 
				DATE_AJOUT_PJ
			) 

			VALUES (
				'{$document}', 
				{$id_u}, 
				'{$date}'
			)";
			// fin requet 1

			$resultat1 = ExecuterRequetMisAJour($requet1);

			if ($resultat1) 
			{
				// requet 2
				$requet2 = "SELECT ID_PJ 
				FROM piece_jointe 
				WHERE NOM_PJ = '{$document}' 
				AND ID_U = {$id_u} 
				AND DATE_AJOUT_PJ = '{$date}'";
				// fin requet 2

				$resultat2 = ExecuterRequetRecuperation($requet2);

				if ($resultat2) 
				{
					// requet 3
					$requet3 = "INSERT INTO reponse(
						ID_REC, 
						ID_U, 
						ID_PJ, 
						DATE_REP, 
						REP
					) 
					VALUES (
						{$id_rec}, 
						{$id_u}, 
						{$resultat2['ID_PJ']}, 
						'{$date}', 
						'{$reponse}'
					)";
					// fin requet 3

					$resultat3 = ExecuterRequetMisAJour($requet3);

					if ($resultat3) 
					{
						// requet 4
						$requet4 = "UPDATE reclamation 
						SET ID_ETAT = 2, 
							ID_PRI = 4 
						WHERE ID_REC = {$id_rec}";
						// fin requet 4

						$resultat4 = ExecuterRequetMisAJour($requet4); 

						if ($resultat4) {
							header("Location: ../Reponses.php?id_rec={$id_rec}");
						}
					}
					else
					{
						header("Location: ../Reponses.php?id_rec={$id_rec}");
					}
				} 
			}
		}
		else
		{
			// requet 5
			$requet5 = "INSERT INTO reponse(
				ID_REC, 
				ID_U, 
				ID_PJ, 
				DATE_REP, 
				REP
			) 
			VALUES (
				{$id_rec}, 
				{$id_u}, 
				1, 
				'{$date}', 
				'{$reponse}'
			)";

			$resultat5 = ExecuterRequetMisAJour($requet5);

			if ($resultat5) 
			{
				// requet 6
				$requet6 = "UPDATE reclamation 
				SET ID_ETAT = 2, 
					ID_PRI = 4 
				WHERE ID_REC = {$id_rec}";
				// fin requet 6

				$resultat6 = ExecuterRequetMisAJour($requet6);
				
				if ($resultat6) {
					header("Location: ../Reponses.php?id_rec={$id_rec}");
				}

			}
			else
			{
				header("Location: ../Reponses.php?id_rec={$id_rec}");
			}
		}
	}
?>