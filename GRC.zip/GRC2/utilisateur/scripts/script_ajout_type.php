<?php
    // inclusion des fonctions
    include_once '../includes/fonctions.php';
    if (isset($_POST[ 'ajout'])) {
        // recuperation des données
        $nom_type = $_POST[ 'nom_type'];
        $gerant_agence = $_POST['gerant_agence'];
        $adress_agence = $_POST['adress_agence'];
        // requet 
        $requet = "INSERT INTO type(NOM_TYPE) VALUE('{$nom_type}')";
        $resultat = ExecuterRequetMisAJour($requet);

        if ($resultat) {
            // redirection + message de reussite 
            header("Location: ../gestion_type.php?msg=op_re");
        }
    }
