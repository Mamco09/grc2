<?php
	include_once '../includes/fonctions.php';
	ob_start();
	session_start();
	if (isset($_POST['mod_user'])) 
	{
		// recuperation de l'id envoyer avec get method
		$id = $_GET['id'];

		// recuperations des infos envoyer par post method 
		$prenom = $_POST['prenom'];
		$nom = $_POST['nom'];
		$genre = $_POST['genre'];
		$tel = $_POST['tel'];
		$date = $_POST['date'];
		$num_compt = $_POST['num_compt'];

		// requet de mis a jour admin
	 	$requet = "UPDATE client SET PRENOM_CLI = '{$prenom}', NOM_CLI = '{$nom}', GENRE_CLI = '{$genre}', TEL_CLI = {$tel}, DATE_NAISS_CLI = '{$date}', NUM_COMPT_CLI = {$num_compt} WHERE ID_CLI = {$id}";
		
		// execution de la requet
		$resultat = ExecuterRequetMisAJour($requet);

		// verification du resultat de la requet 
		if ($resultat) {
			
			header( "Location: ../tout_les_clients.php?msg=op_re");
		}
		else{
		// renvoie vers /index.php
		// op_ec = operation echouer
	
		header( "Location: ../tout_les_clients.php?msg=op_ec");
		}
	}
?> 