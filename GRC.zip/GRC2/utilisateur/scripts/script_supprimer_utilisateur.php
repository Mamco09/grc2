<?php
	include_once '../includes/fonctions.php';  
	if (isset($_GET['id'])) 
	{
        $id = $_GET['id'];
		// requet de suppression utilisateur
        $requet = "DELETE FROM utilisateur WHERE ID_U = {$id}";
		// execution de la requet
		$resultat = ExecuterRequetMisAJour($requet);

		// verification du resultat de la requet 
		if ($resultat) {
			// renvoie vers /tout_les_utilisateur.php
			// op_re = operation reussie
			header("Location: ../tout_les_utilisateur.php?msg=op_re");
		}
		else{
			// renvoie vers /tout_les_utilisateur.php
			// op_ec = operation echouer
			header("Location: ../tout_les_utilisateur.php?msg=op_ec");
		}
	}
?>