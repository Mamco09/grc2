<?php
    // inclusion des fonctions
    include_once '../includes/fonctions.php';
    if (isset($_POST[ 'ajout'])) {
        // recuperation des données
        $nom_agence = $_POST[ 'nom_agence'];
        $adress_agence = $_POST['adress_agence'];
        // requet 
        $requet = "INSERT INTO agence(NOM_AG, ADRESSE_AG) VALUES('{$nom_agence}', '{$adress_agence}')";
        $resultat = ExecuterRequetMisAJour($requet);

        if ($resultat) {
            // redirection + message de reussite 
            header("Location: ../gestion_agence.php?msg=op_re");
        }
    }
