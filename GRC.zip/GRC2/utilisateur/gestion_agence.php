<?php
// inclusion de la head
include_once 'includes/head.php'; 
?>

<body>
  <?php $_SESSION['page_actuel'] = basename(__FILE__); ?>
  <!-- wrapper -->
  <div class="wrapper">
    <!-- Sidebar  -->
    <?php include_once 'includes/sidebar.php'; ?>

    <!-- Page Content  -->
    <div id="content">
      <!-- navbar  -->
      <?php include_once 'includes/navbar.php'; ?>

      <!-- container -->
      <div class="container">

        <div class="row">
          <!-- div col 12 -->
          <div class="col-md-12">

            <?php AfficheMessage(); 
            ?>

            <div class="header">
              <nav class="navbar navbar-light bg-light pull-right">

                <h1>Tout Les Agence</h1>
                <form class="form-inline ">
                  <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                  <button class="btn btn-outline-secondary my-2 my-sm-0" type="submit">Search</button>
                </form>
              </nav>
              <?php
              // requet de selection de les agences simple
              $requet = "SELECT * FROM agence";
              $resultat_agence = ExecuterRequetPlusieurResultat($requet);
              $nomre_de_resultat_agence = count($resultat_agence);
              ?>
            </div>
            <!-- ////div col 12 -->
          </div>

          <hr>
          <!-- div col 12 -->
          <div class="col-md-12 ml-auto mr-auto">
            <h2>Agences </h2>
            <table class="table">
              <thead class="thead-light">
                <tr>
                  <th scope="col" colspan="7" style='text-align:center;'>
                    <a href='' data-toggle='modal' data-target='#ajout_agence'>Ajouter Nouvel Agence</a>
                    <!-- Modiifer Modal -->
                    <div class='modal fade' id='ajout_agence' tabindex='-1' role='dialog' aria-labelledby='ajout_agenceLabel' aria-hidden='true'>
                      <div class='modal-dialog' role='document'>
                        <!-- modal-content -->
                        <div class='modal-content'>
                          <!-- modal-header -->
                          <div class='modal-header'>
                            <h5 class='modal-title' id='ajout_agenceLabel'>Mis a jour des infos Agence</h5>
                            <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                              <span aria-hidden='true'>&times;</span>
                            </button>
                            <!-- modal-header -->
                          </div>
                          <div class='modal-body'>
                            <!-- form -->
                            <form action='scripts/script_ajout_agence.php' method='POST'>
                                <!-- div form group nom de l'agence -->
                                <div class='form-group'>
                                  <label for='recipient-name' class='col-form-label'>Nom de l'agence:</label>
                                  <input type='text' class='form-control' name='nom_agence'>
                                </div>
                                    <div class='form-group'>
                                      <label for='recipient-name' class='col-form-label'>Adresse agence:</label>
                                      <input type='text' class='form-control' name='adress_agence'>
                                    </div>
                                    <div class='modal-footer'>
                                      <button type='button' class='btn btn-secondary' data-dismiss='modal'>Annulé</button>
                                      <button type='submit' class='btn btn-primary' name='ajout'>Comfirmé</button>
                                    </div>
                                    <!-- ////form -->
                            </form>
                          </div>
                          <!-- modal-content -->
                        </div>
                      </div>
                    </div>
                  </th>
                </tr>
                <tr class="thead-light">
                  <th scope="col">#</th>
                  <th scope="col">Nom Agence</th>
                  <th scope="col">Adresse</th>
                  <th scope="col"></th>
                  <th scope="col"></th>
                  <th scope="col"></th>
                </tr>
              </thead>
              <tbody>
                <?php
                if ($nomre_de_resultat_agence == 0) {
                  echo "
                      <tr>
                      <th colspan='4'><center>Aucun agence</center></th>
                      </tr>
                   ";
                } else {
                  for ($i = 0; $i < $nomre_de_resultat_agence; $i++) {
                    $line = $i + 1;
                    // nom de l'agence, nom complet du gerant, adresse de l'agence
                    // l'arret de script pou le html
                    ?>
                    <!-- tr -->
                    <tr>
                      <th scope='row'><?php echo $line; ?></th>
                      <td><?php echo $resultat_agence[$i]['NOM_AG']; ?></td>
                      <td><?php echo $resultat_agence[$i]['ADRESSE_AG']; ?></td>
                      <td>
                        <a href='' data-toggle='modal' data-target='.bd-example-modal-lg<?php echo $i; ?>'>
                          <i class='fas fa-info'></i>
                        </a>
                      </td>
                      <td><a href='' data-toggle='modal' data-target='#mod_agence<?php echo $i; ?>'><i class='fas fa-edit'></i></a></td>
                      <td><a href='' data-toggle='modal' data-target='#sup_mod<?php echo $i; ?>'><i class='fas fa-trash'></i></a></td>
                      <!-- ////tr -->
                    </tr>
                    <!-- infos modal -->
                    <div class='modal fade bd-example-modal-lg<?php echo $i; ?>' tabindex='-1' role='dialog' aria-labelledby='myLargeModalLabel' aria-hidden='true'>
                      <div class='modal-dialog modal-lg'>

                        <div class='modal-content'>

                          <div class='modal-header'>
                            <h5 class='modal-title'>Informations Sur <?php echo $resultat_agence[$i]["NOM_AG"]; ?></h5>
                            <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                              <span aria-hidden='true'>&times;</span>
                            </button>
                          </div>

                          <ul class='list-group'>
                            <li class='list-group-item'>Nom de l'agence: <?php echo $resultat_agence[$i]["NOM_AG"]; ?></li>
                            <li class='list-group-item'>Adresse : <?php echo $resultat_agence[$i]["ADRESSE_AG"]; ?></li>
                          </ul>

                        </div>
                      </div>
                      <!-- ////infos modal -->
                    </div>

                    <!-- Supprimer Modal -->
                    <div class='modal fade' id='sup_mod<?php echo $i; ?>' tabindex='-1' role='dialog' aria-labelledby='sup_mod<?php echo $i; ?>Label' aria-hidden='true'>
                      <div class='modal-dialog' role='document'>
                        <div class='modal-content'>
                          <div class='modal-header'>
                            <h5 class='modal-title' id='sup_mod<?php echo $i; ?>Label'>Confirmation</h5>
                            <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                              <span aria-hidden='true'>&times;</span>
                            </button>
                          </div>
                          <div class='modal-body'>
                            <b>Supprimer l agence <?php echo $resultat_agence[$i]['NOM_AG']; ?></b>
                            <p>Etes vous sure ?</p>
                          </div>
                          <div class='modal-footer'>
                            <button type='button' class='btn btn-secondary' data-dismiss='modal'>Annulé</button>
                            <a href='scripts/script_supprimer_agence.php?id=<?php echo $resultat_agence[$i]['ID_AG']; ?>' class='btn btn-primary'>Comfirmer</a>
                          </div>
                        </div>
                      </div>
                    </div>


                    <!-- Modiifer Modal -->
                    <div class='modal fade' id='mod_agence<?php echo $i; ?>' tabindex='-1' role='dialog' aria-labelledby='mod_agence<?php echo $i; ?>Label' aria-hidden='true'>
                      <div class='modal-dialog' role='document'>
                        <!-- modal-content -->
                        <div class='modal-content'>
                          <!-- modal-header -->
                          <div class='modal-header'>
                            <h5 class='modal-title' id='mod_agence<?php echo $i; ?>Label'>Mis a jour des infos Agence</h5>
                            <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                              <span aria-hidden='true'>&times;</span>
                            </button>
                            <!-- modal-header -->
                          </div>
                          <div class='modal-body'>
                            <!-- form -->
                            <form action='scripts/script_mis_a_jour_agence.php?id=<?php echo $resultat_agence[$i]['ID_AG'] ?>' method='POST'>
                              <div class='form-group'>
                                <label for='recipient-name' class='col-form-label'>Nom agence:</label>
                                <input type='text' class='form-control' name='nom' value='<?php echo $resultat_agence[$i]['NOM_AG'] ?>'>
                              </div>
                              
                                <div class='form-group'>
                                  <label for='recipient-name' class='col-form-label'>Adresse agence:</label>
                                  <input type='text' class='form-control' name='adress' value='<?php echo $resultat_agence[$i]['ADRESSE_AG'] ?>'>
                                </div>
                                <div class='modal-footer'>
                                  <button type='button' class='btn btn-secondary' data-dismiss='modal'>Annulé</button>
                                  <button type='submit' class='btn btn-primary' name='submit'>Comfirmé</button>
                                </div>
                                <!-- ////form -->
                            </form>
                          </div>
                          <!-- modal-content -->
                        </div>
                      </div>
                    </div>
                  <?php
                }
              }
              ?>
              </tbody>
            </table>
            <hr>
            <!-- ////div col 12 -->
          </div>

        </div>
        <!-- ///container -->
        <!-- ////container -->
      </div>

      <!-- ////Page Content  -->
    </div>

    <!-- ////wrapper -->
  </div>

  <div class="overlay"></div>
  <?php
  include_once 'includes/scripts.php';
  ?>
</body>

</html>