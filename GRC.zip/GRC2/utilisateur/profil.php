<?php
// inclusion de la head
include_once 'includes/head.php';
// redireition de la page actuel 
$_SESSION['page_actuel'] = "profil.php";
?>

<body>
    <?php $_SESSION['page_actuel'] = basename(__FILE__); ?>
    <!-- wrapper -->
    <div class="wrapper">
        <!-- Sidebar  -->
        <?php include_once 'includes/sidebar.php'; ?>
        <!-- ////Sidebar  -->

        <!-- Page Content  -->
        <div id="content">
            <!-- navbar  -->
            <?php include_once 'includes/navbar.php'; ?>
            <!-- ////navbar  -->

            <!-- container -->
            <div class="container">
                <!-- row -->
                <div class="row">
                    <!-- div de 12 colonne -->
                    <div class="col-md-12">
                        <div class="header">
                            <?php 
                                // fonction affichant les message d'erreur 
                                AfficheMessage(); 
                            ?>

                            <h1>Mon Profil</h1>

                            <?php
                            // requet de recuperation utilisateur
                            $requet = "SELECT * FROM utilisateur INNER JOIN profil INNER JOIN agence WHERE utilisateur.ID_PROFIL = profil.ID_PROFIL AND utilisateur.ID_AG = agence.ID_AG AND ID_U = {$_SESSION['id']}";
                            // execution de la requet 
                            $resultat = ExecuterRequetRecuperation($requet);
                            ?>
                        </div>
                    <!-- //// div de 12 colonne -->
                    </div>
                    <!-- ligne stiliser -->
                    <div class="line"></div>
                    <!-- div de 12 colonne -->
                    <div class="col-md-12">
                        <!-- list-group -->
                        <ul class="list-group">
                            <li class="list-group-item">Prenom: <?php echo $resultat['PRENOM_U']; ?></li>
                            <li class="list-group-item">Nom : <?php echo $resultat['NOM_U']; ?></li>
                            <li class="list-group-item">Genre : <?php echo $resultat['GENRE_U']; ?></li>
                            <li class="list-group-item">Tel : <?php echo $resultat['TEL_U']; ?></li>
                            <li class="list-group-item">Date Naiss : <?php echo $resultat['DATE_NAISS_U']; ?></li>
                            <li class="list-group-item">Identifiant : <?php echo $resultat['IDENTIFIANT_U']; ?></li>
                            <li class="list-group-item">Agence : <?php echo $resultat['NOM_AG']; ?></li>
                            <li class="list-group-item">Pofil : <?php echo $resultat['NOM_PROFIL']; ?></li>
                        <!-- //// list-group -->
                        </ul>
                        <hr>
                        <!-- lien class: btn -->
                        <a href="mis_a_jour_profil.php?id=<?php echo $resultat['ID_U'] ?>" class="btn btn-primary pull-right">
                            Metre a jour Profil
                        </a>
                    <!-- //// div de 12 colonne -->
                    </div>
                <!-- ////row -->
                </div>
            </div>
            <!-- ///container -->
        <!-- ////Page Content  -->   
        </div>
    </div>
    <!-- line stiliser -->
    <div class="overlay"></div>


    <?php
        // inclusion de sceript js
        include_once 'includes/scripts.php'; 
    ?>
</body>

</html>