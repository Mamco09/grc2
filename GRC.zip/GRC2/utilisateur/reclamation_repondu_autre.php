<?php
// inclusion de la head
include_once 'includes/head.php';
// redireition de la page actuel 
$_SESSION['page_actuel'] = "reclamation_envoyer.php";
?>

<body>
    <?php $_SESSION['page_actuel'] = basename(__FILE__); ?>    
    <div class="wrapper">
        <!-- Sidebar  -->
        <?php include_once 'includes/sidebar.php'; ?>

        <!-- Page Content  -->
        <div id="content">

            <!-- navbar  -->
            <?php include_once 'includes/navbar.php'; ?>

            <!-- container -->
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <?php
                        // fonction affichant les message d'erreur
                        AfficheMessage();
                        ?>
                        <!-- header -->
                        <div class="header">
                            <nav class="navbar navbar-light bg-light pull-right">

                                <h1>Tout Les Rclamation Repondue</h1>
                                <?php   include_once 'includes/search.php' ?>
                            </nav>
                            <?php
                            // requet de selection de les utilisateurs simple
                            $requet = "SELECT * 
                            FROM reclamation 
                            INNER JOIN utilisateur
                            INNER JOIN type 
                            INNER JOIN etat 
                            INNER JOIN priorite 
                            INNER JOIN piece_jointe 
                            INNER JOIN agence 
                            INNER JOIN profil 
                            WHERE reclamation.ID_U = utilisateur.ID_U 
                            AND reclamation.ID_TYPE = type.ID_TYPE 
                            AND reclamation.ID_ETAT = etat.ID_ETAT 
                            AND reclamation.ID_PRI = priorite.ID_PRI 
                            AND reclamation.ID_PJ = piece_jointe.ID_PJ 
                            AND utilisateur.ID_AG = agence.ID_AG 
                            AND utilisateur.ID_PROFIL = profil.ID_PROFIL 
                            AND reclamation.ID_ETAT = 2 
                            AND reclamation.ID_U != {$_SESSION['id']}
                            ORDER BY reclamation.DATE_REC DESC";

                            $resultat_rec_env = ExecuterRequetPlusieurResultat($requet);

                            $nomre_de_resultat_rec_env = count($resultat_rec_env);
                            ?>
                        </div>
                        <!-- ////header -->
                    </div>

                    <hr>
                    <!-- div de 12 colone  -->
                    <div class="col-md-12 ml-auto mr-auto">
                        <h2>Reclamations Repondue</h2>
                        <?php
                        // tesst si le resultat est vide
                        if ($nomre_de_resultat_rec_env == 0) 
                            { 
                                echo "<center>Aucune Reclamation</center>";
                            } 
                            else 
                            {
                            for ($i = 0; $i < $nomre_de_resultat_rec_env; $i++) {
                                if ($resultat_rec_env[$i]['ID_ETAT'] == 2) {

                                    ?>
<div class="accordion" id="accordionExample">
    <div class="card">
        <div class="card-header <?php get_rec_color($resultat_rec_env[$i]['NOM_PRI']); ?>" id="heading<?php echo $resultat_rec_env[$i]['ID_REC']; ?>">
            <h2 class="mb-0">
                <button class="btn btn-link" style="color:white;" type="button" data-toggle="collapse" data-target="#collapse<?php echo $resultat_rec_env[$i]['ID_REC']; ?>" aria-expanded="true" aria-controls="collapseOne">

                    <i class="fa fa-tags" aria-hidden="true"></i> : <?php echo $resultat_rec_env[$i]['ID_REC']; ?> &nbsp 
                    <em><i class="fa fa-calendar" aria-hidden="true"></i> : <?php echo $resultat_rec_env[$i]['DATE_REC']; ?> </em>&nbsp
                    <em><i class="fa fa-comments" aria-hidden="true"></i> :  
                        <?php 
                            $requet = "SELECT * FROM reponse WHERE ID_REC = {$resultat_rec_env[$i]['ID_REC']}";
                            $resultat = ExecuterRequetPlusieurResultat($requet);
                            echo count($resultat);
                        ?>
                    </em>
                </button>
            </h2>
        </div>

        <div id="collapse<?php echo $resultat_rec_env[$i]['ID_REC']; ?>" class="collapse" aria-labelledby="heading<?php echo $resultat_rec_env[$i]['ID_REC']; ?>" data-parent="#accordionExample">
            <div class="card-body">
                <div class="card text-center">
                    <div class="card-header">
                        Envoyer par : <strong><?php echo $resultat_rec_env[$i]['PRENOM_U'] . " " . $resultat_rec_env[$i]['NOM_U']; ?></strong> 
                        <em>(<?php echo $resultat_rec_env[$i]['NOM_PROFIL'] ?> de l'agence <?php echo $resultat_rec_env[$i]['NOM_AG'] ?>)</em>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Reclamation de type <?php echo $resultat_rec_env[$i]['NOM_TYPE']; ?> 
                            <em>(Client Tel : <?php echo $resultat_rec_env[$i]['TEL_CLI']; ?> Num compte: <?php echo $resultat_rec_env[$i]['NUM_CLI']; ?>)</em>
                        </h5>
                        <p><strong>Description :</strong></p>
                        <p class="card-text"><?php echo $resultat_rec_env[$i]['DESCRIPTION_REC']; ?></p>
                        <p><strong>Infos Complementaire :</strong></p>
                        <p class="card-text"><?php echo $resultat_rec_env[$i]['INFO_COMP_REC']; ?></p>
                        <p><strong><i class="fa fa-file" aria-hidden="true"></i>  Piece jointe :</strong>
                            <?php
                            $requet = "SELECT * FROM piece_jointe WHERE ID_PJ = {$resultat_rec_env[$i]['ID_PJ']}";
                            $resultat = ExecuterRequetRecuperation($requet);
                            if ($resultat_rec_env[$i]['ID_PJ'] != 1) {

                                echo "<a href='doc/{$resultat['NOM_PJ']}' style='color:blue'>{$resultat['NOM_PJ']}</a>";
                            }
                            else {
                                echo "AUCUNE";
                            }
                            ?>
                        </p>
                        <a href="Reponses.php?id_rec=<?php echo $resultat_rec_env[$i]['ID_REC']; ?>" class=""><i class="fa fa-eye" aria-hidden="true"></i> Voir les reponses</a>
                        <br><br><br>
                        <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal<?php echo $i; ?>" data-whatever="@mdo">Repondre</a>
                        <a href="scripts/script_confirmer.php?id=<?php echo $resultat_rec_env[$i]['ID_REC']; ?>" class="btn btn-success">confirmer</a>

                            <form action="scripts/script_reponse.php?id_rec=<?php echo $resultat_rec_env[$i]['ID_REC']; ?>" method="POST" enctype="multipart/form-data">
                                <div class="modal fade" id="exampleModal<?php echo $i; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModal<?php echo $i; ?>Label" aria-hidden="true">
                                  <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModal<?php echo $i; ?>Label">Reponse</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                          <span aria-hidden="true">&times;</span>
                                        </button>
                                      </div>
                                      <div class="modal-body">
                                        <form>
                                          <div class="custom-file">
                                                <label for="message-text" class="col-form-label">Piece Jointe :</label>
                                                <input type="file" name="document">
                                            </div>
                                          <div class="form-group">
                                            <label for="message-text" class="col-form-label">Reponse:</label>
                                            <textarea class="form-control" id="message-text" name="reponse" required></textarea>
                                          </div>
                                        </form>
                                      </div>
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annulé</button>
                                        <button type="submit" class="btn btn-primary" name="submit">Repondre</button>

                                      </div>
                                    </div>
                                  </div>
                                </div>
                            </form>
                    </div>
                    <div class="card-footer text-muted">

                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
                                <?php

                            }
                        }
                    }
                    ?>

                    </div>
                    <!-- ////div de 12 colone  -->
                </div>
            </div>
            <!-- ///container -->
        </div>
    </div>
    </div>

    <div class="overlay"></div>
    <?php
    include_once 'includes/scripts.php';
    ?>
</body>

</html>