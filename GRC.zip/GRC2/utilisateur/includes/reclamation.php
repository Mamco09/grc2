<div class="accordion" id="accordionExample">
    <!-- card start -->
    <div class="card">
        <!-- card header -->
        <div class="card-header <?php get_rec_color($resultat_rec_env[$i]['NOM_PRI']); ?>" id="heading<?php echo $resultat_rec_env[$i]['ID_REC']; ?>">
            <h2 class="mb-0">
                <!-- button start -->
                <button class="btn btn-link" style="color:white;" type="button" data-toggle="collapse" data-target="#collapse<?php echo $resultat_rec_env[$i]['ID_REC']; ?>" aria-expanded="true" aria-controls="collapseOne">

                    <i class="fa fa-tags" aria-hidden="true"></i> : <?php echo $resultat_rec_env[$i]['ID_REC'];// numero de la reclamation?>


                    <em>
                        <?php space(); ?><i class="fa fa-calendar" aria-hidden="true"></i> :
                        <?php echo $resultat_rec_env[$i]['DATE_REC']; // date de la reclamation 
                        ?>
                    </em>


                    <em><?php space(); ?><i class="fa fa-comments" aria-hidden="true"></i> :

                        <?php
                        //affichage du nombre de reponse 
                        $requet = "SELECT * FROM reponse WHERE ID_REC = {$resultat_rec_env[$i]['ID_REC']}";
                        $resultat = ExecuterRequetPlusieurResultat($requet);
                        echo count($resultat);
                        ?>

                        <?php
                        //affiche qu'il ya piece jointe
                        if ($resultat_rec_env[$i]['ID_PJ'] != 1) {
                            space();
                            echo "<i class='fas fa-file-alt'></i>: 1";
                        } else {
                            space();
                            echo "<i class='fas fa-file-alt'></i>: 0";
                        }
                        ?>


                        <?php space(); ?>(<?php echo $resultat_rec_env[$i]['NOM_TYPE']; // tyle de la reclamation 
                                            ?>)
                    </em>

                    <?php
                    //affiche si c'est comfirmer
                    if ($resultat_rec_env[$i]['ID_ETAT'] == 3) {
                        space();
                        echo "<i class='fas fa-check'></i>";
                    }
                    ?>
                </button>
                <!-- ////button start -->
            </h2>
        </div>
        <!-- ////card header -->

        <div id="collapse<?php echo $resultat_rec_env[$i]['ID_REC']; ?>" class="collapse" aria-labelledby="heading<?php echo $resultat_rec_env[$i]['ID_REC']; ?>" data-parent="#accordionExample">

            <!-- card body start -->
            <div class="card-body">

                <div class="card text-center">
                    <div class="card-header">
                        Envoyer par : 
                        <?php 
                            if ( $resultat_rec_env[$i]['ID_U'] == $_SESSION['id']) {
                                echo "Vous";
                            }
                            else{
                                echo $resultat_rec_env[$i]['PRENOM_U'] . " " . $resultat_rec_env[$i]['NOM_U'];
                            }
                        ?>
                        </strong>
                        <em>
                            (<?php echo $resultat_rec_env[$i]['NOM_PROFIL'] // nom de l'utilisateur qui a envoyer la reclamation
                                ?>

                            de l'agence <?php echo $resultat_rec_env[$i]['NOM_AG'] // nom de l'agence
                                        ?>)
                        </em>

                    </div>
                    <div class="card-body">
                        <h5 class="card-title">
                            Reclamation de type <?php echo $resultat_rec_env[$i]['NOM_TYPE']; // tyle de la reclamation 
                                                ?>
                            <em>
                                (
                                Client: Tel <?php echo $resultat_rec_env[$i]['TEL_CLI']; ?>
                                Num compte: <?php echo $resultat_rec_env[$i]['NUM_CLI']; ?>
                                )
                            </em>
                        </h5>

                        <p>
                            <strong>Description :</strong>
                        </p>
                        <p class="card-text"><?php echo $resultat_rec_env[$i]['DESCRIPTION_REC']; ?></p>

                        <p>
                            <strong>Infos Complementaire :</strong>
                        </p>
                        <p class="card-text"><?php echo $resultat_rec_env[$i]['INFO_COMP_REC']; ?></p>

                        <p>
                            <strong><i class="fa fa-file" aria-hidden="true"></i> Piece jointe :</strong>
                            <?php
                            // recuperation de la piece jointe
                            $requet = "SELECT * FROM piece_jointe WHERE ID_PJ = {$resultat_rec_env[$i]['ID_PJ']}";
                            $resultat = ExecuterRequetRecuperation($requet);
                            if ($resultat_rec_env[$i]['ID_PJ'] != 1) {

                                echo "<a href='doc/{$resultat['NOM_PJ']}' style='color:blue'>{$resultat['NOM_PJ']}</a>";
                            } else {
                                echo "AUCUNE";
                            }
                            ?>
                        </p>

                        <?php
                        if ($resultat_rec_env[$i]['ID_ETAT'] != 1)
                        {
                         
                        //affichage du nombre de reponse 
                        $requet = "SELECT * FROM reponse  WHERE ID_REC = {$resultat_rec_env[$i]['ID_REC']}";
                        $resultat = ExecuterRequetPlusieurResultat($requet);
                        $nb = count($resultat);
                       
                        echo "<a href='Reponses.php?id_rec=" . $resultat_rec_env[$i]['ID_REC'] . "' ><i class='fa fa-eye' aria-hidden='true' > </i> Voir les reponses: ". $nb." </a>" ; 
                        } 
                        else 
                        { 
                            echo "<i class=' fas fa-eye-slash'></i> Pas de reponse " ; 
                        } 
                        ?>
                            <br><br><br>

                            <?php
                            // affichage du button de confirmation  
                            if ($resultat_rec_env[$i]['ID_ETAT'] != 2 and $resultat_rec_env[$i]['ID_ETAT'] != 3) {
                                echo '<a href="#" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal' . $i . '" data-whatever="@mdo">Repondre</a>';
                            }
                            ?>


                            <?php
                            // affichage du button de confirmation  
                            if ($resultat_rec_env[$i]['ID_ETAT'] == 2) {
                                echo '<a href="scripts/script_confirmer.php?id=' . $resultat_rec_env[$i]['ID_REC'] . '" class="btn btn-success">confirmer</a>';
                            }
                            ?>
                            <!-- formulaire de reponse -->
                            <form action="scripts/script_reponse.php?id_rec=<?php echo $resultat_rec_env[$i]['ID_REC']; ?>" method="POST" enctype="multipart/form-data">
                                <div class="modal fade" id="exampleModal<?php echo $i; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModal<?php echo $i; ?>Label" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModal<?php echo $i; ?>Label">Reponse</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <form>
                                                    <div class="custom-file">
                                                        <label for="message-text" class="col-form-label">Piece Jointe :</label>
                                                        <input type="file" name="document">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="message-text" class="col-form-label">Reponse:</label>
                                                        <textarea class="form-control" id="message-text" name="reponse" required></textarea>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Annulé</button>
                                                <button type="submit" class="btn btn-primary" name="submit">Repondre</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <!-- ////formulaire de reponse -->
                    </div>
                    <div class="card-footer text-muted">

                    </div>
                </div>
            </div>
            <!-- ////card body start -->
        </div>
    </div>

</div>