<form class="form-inline" method="POST" action="scripts/script_recherche.php?page=<?php echo $_SESSION['page_actuel']; ?>">
    <input class="form-control mr-sm-2" type="search" placeholder="Rechercher..." aria-label="Search" name="recherche">
    <button class="btn btn-outline-secondary my-2 my-sm-0" type="submit" name="search">Rechercher</button>
</form>