<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">

        <button type="button" id="sidebarCollapse" class="btn btn-info">
            <i class="fas fa-align-left"></i>
            <span>Menu</span>
        </button>
        <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <i class="fas fa-align-justify"></i>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="nav navbar-nav ml-auto">
                <li class="nav-item">
                    <a href="" class="nav-link" data-toggle="modal" data-target="#reclamation"><i class="fa fa-envelope" aria-hidden="true"></i> Nouvel Reclamations</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="profil.php"><i class="fa fa-user" aria-hidden="true"></i> <?php echo $_SESSION['nom_complet']; ?></a>
                </li>
                <?php
                if ($_SESSION['profil'] == "ADMINISTRATEUR") {
                    echo '
                        <li class="nav-item">
                            <a class="nav-link" href="parametres.php"><i class="fa fa-cog" aria-hidden="true"></i> Parametres</a>
                        </li>
                        ';
                }
                ?>
                <li class="nav-item">
                    <a class="nav-link" href="../index.php"><i class="fa fa-power-off" aria-hidden="true"></i> Deconnexion</a>
                </li>
            </ul>
            <div class="modal fade" id="reclamation" tabindex="-1" role="dialog" aria-labelledby="reclamationLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="reclamationLabel">Nouvel Reclamation</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="scripts/script_nouvel_reclamation.php?id=<?php echo $_SESSION['id']; ?>" enctype="multipart/form-data" method="POST">
                                <div class="form-group">
                                    <label for="recipient-name" class="col-form-label">Client Num Compte:</label>
                                    <input type="number" class="form-control" name="num_comp_cli" maxlength="11" required>
                                </div>
                                <div class="form-group">
                                    <label for="recipient-name" class="col-form-label">Client Tel:</label>
                                    <input type="number" class="form-control" name="tel_cli" required>
                                </div>
                                <div class="form-group">
                                    <label for="recipient-name" class="col-form-label">Type:</label>
                                    <select name="type" id="" class="form-control">
                                        <?php
                                        // affichage des type
                                        $requet = "SELECT * FROM type";
                                        $resultat = ExecuterRequetPlusieurResultat($requet);
                                        for ($i = 0; $i < count($resultat); $i++) {
                                            echo "
                                        <option value='{$resultat[$i]['ID_TYPE']}'>{$resultat[$i]['NOM_TYPE']}</option>
                                    ";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="recipient-name" class="col-form-label">Priorité:</label>
                                    <select name="priorite" id="" class="form-control">
                                        <?php
                                        // affichage des priorite
                                        $requet = "SELECT * FROM priorite";
                                        $resultat = ExecuterRequetPlusieurResultat($requet);
                                        for ($i = 0; $i < count($resultat); $i++) {
                                            echo "
                                        <option value='{$resultat[$i]['ID_PRI']}'>{$resultat[$i]['NOM_PRI']}</option>
                                    ";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="message-text" class="col-form-label">Description:</label>
                                    <textarea class="form-control" id="message-text" name="description" required></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="message-text" class="col-form-label">Infos Complementaire (optionnel):</label>
                                    <textarea class="form-control" id="message-text" name="infosComplementaire"></textarea>
                                </div>
                                <div class="custom-file">
                                    <label for="message-text" class="col-form-label">Piece Jointe:</label>
                                    <input type="file" name="document">
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annulé</button>
                                    <button type="submit" class="btn btn-primary" name="submit"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</nav>