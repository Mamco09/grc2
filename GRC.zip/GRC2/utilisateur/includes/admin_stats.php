    <div class="row">
        <div class="col-lg-3 col-md-6">
            <div class="card bg-info">
                <div class="card-header">
                    <div class="row">
                        <div class="col-xs-3">
                            <i class="fa fa-file fa-5x" aria-hidden="true"></i>
                        </div>
                        <div class="col-xs-9 text-right">
                            <?php  
                                $requet = "SELECT * FROM reclamation";
                                $resultat = ExecuterRequetPlusieurResultat($requet);
                                $nb_reclamation = count($resultat);
                            ?>
                      <div class='huge'> <strong style="font-size: 3rem;"><?php echo $nb_reclamation; ?></strong></div>
                            <div><strong style="font-size: 1rem;">&nbspReclamation <br> Envoyé</strong></div>
                        </div>
                    </div>
                </div>
                <a href="detail_rec_envoyer.php">
                    <div class="card-footer">
                        <span class="pull-left">Plus de Details</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="card bg-success">
                <div class="card-header">
                    <div class="row">
                        <div class="col-xs-3">
                            <i class="fa fa-comments fa-5x"></i>
                        </div>
                        <div class="col-xs-9 text-right">
                            <?php  
                                $requet = "SELECT * FROM reclamation WHERE ID_ETAT != 3";
                                $resultat = ExecuterRequetPlusieurResultat($requet);
                                $nb_reclamation_repondu = count($resultat);
                            ?>
                         <div class='huge'> <strong style="font-size: 3rem;"><?php echo $nb_reclamation_repondu; ?></strong></div>
                               <div><strong style="font-size: 1rem;">&nbspReclamations <br> Non Confirmé</strong></div>
                        </div>
                    </div>
                </div>
                <a href="detail_re_nom_confirmer.php">
                    <div class="card-footer">
                        <span class="pull-left">Plus de Details</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="card bg-danger">
                <div class="card-header">
                    <div class="row">
                        <div class="col-xs-3">
                            <i class="fa fa-list fa-5x"></i>
                        </div>
                        <div class="col-xs-9 text-right">
                            <?php  
                                $requet = "SELECT * FROM reclamation WHERE ID_ETAT = 3";
                                $resultat = ExecuterRequetPlusieurResultat($requet);
                                $nb_reclamation_confirme = count($resultat);
                            ?>
                         <div class='huge'> <strong style="font-size: 3rem;"><?php echo $nb_reclamation_confirme; ?></strong></div>
                               <div><strong style="font-size: 1rem;">&nbspReclamations <br> Confirmé</strong></div>
                        </div>
                    </div>
                </div>
                <a href="detail_rec_confirme.php">
                    <div class="card-footer">
                        <span class="pull-left">Plus de Details</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="card bg-warning">
                <div class="card-header">
                    <div class="row">
                        <div class="col-xs-3">
                            <i class="fa fa-user fa-5x"></i>
                        </div>
                        <div class="col-xs-9 text-right">
                            <?php  
                                $requet = "SELECT * FROM utilisateur";
                                $resultat = ExecuterRequetPlusieurResultat($requet);
                                $nb_utilisateur = count($resultat);
                            ?>
                         <div class='huge'> <strong style="font-size: 3rem;"><?php echo $nb_utilisateur; ?></strong></div>
                               <div><strong style="font-size: 1rem;">&nbspTout les <br> Utilisateurs</strong></div>
                        </div>
                    </div>
                </div>
                <a href="tout_les_utilisateur.php">
                    <div class="card-footer">
                        <span class="pull-left">Plus de Details</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
    </div>
                    <!-- /.row -->
    <div class="line"></div>

    <div class="row">
        
        <div class="col-md-12">
            <script type="text/javascript">
                  google.charts.load('current', {'packages':['bar']});
                  google.charts.setOnLoadCallback(drawChart);

                  function drawChart() {
                    var data = google.visualization.arrayToDataTable([
                      ['2019', 'valeur'],
                      ['Reclamation Envoyé', <?php echo $nb_reclamation; ?>],
                      ['Reclamation Repondues', <?php echo $nb_reclamation_repondu; ?>],
                      ['Reclamation Confirmé', <?php echo $nb_reclamation_confirme; ?>],
                      ['Utilisateurs', <?php echo $nb_utilisateur; ?>],
                    ]);

                    var options = {
                      chart: {
                        title: 'GRC',
                        subtitle: 'Reclamation, Reponse, utilisateur et clients : 2018-2019',
                      }
                    };

                    var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

                    chart.draw(data, google.charts.Bar.convertOptions(options));
                  }
                </script>
        </div>

    </div>

    <div id="columnchart_material" style="width: 'auto'; height: 500px;"></div>

<!-- fin de la div de 12 colonnes -->
</div>

<!-- ligne horizontal stiliser -->
<div class="line"></div>