<nav id="sidebar">
    <div id="dismiss">
        <i class="fas fa-arrow-left"></i>
    </div>

    <div class="sidebar-header">
        <h3>GRC</h3>
    </div>

    <ul class="list-unstyled components">

        <li class="">
            <a href="index.php">Acceuil</a>
        </li>
        <li>
            <a href="#Reclamations" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-envelope" aria-hidden="true"></i>Mes Reclamations</a>
            <ul class="collapse list-unstyled" id="Reclamations">
                <li>
                    <a href="reclamation_en_attente.php"><i class="fa fa-envelope" aria-hidden="true"></i>Mes Reclamations en attentes</a>
                </li>
                <li>
                    <a href="reclamation_repondu.php"><i class="fa fa-envelope-open" aria-hidden="true"></i>Mes Reclamations Repondues (non confirmé)</a>
                </li>
                <li>
                    <a href="reclamation_confirmer.php"><i class="fa fa-envelope" aria-hidden="true"></i>Mes Reclamations Confirmé</a>
                </li>
            </ul>
        </li>
        <li>
            <a href="#Reclamations" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-envelope" aria-hidden="true"></i>Autre Reclamations</a>
            <ul class="collapse list-unstyled" id="Reclamations">
                <li>
                    <a href="reclamation_envoyer_autre.php"><i class="fa fa-envelope" aria-hidden="true"></i>Reclamations en attentes</a>
                </li>
                <li>
                    <a href="reclamation_repondu_autre.php"><i class="fa fa-envelope-open" aria-hidden="true"></i>Reclamations Repondues</a>
                </li>
                <li>
                    <a href="reclamation_confirmer_autre.php"><i class="fa fa-envelope" aria-hidden="true"></i>Reclamations Confirmé</a>
                </li>
            </ul>
        </li>
        <?php 
            if ($_SESSION['profil'] == "ADMINISTRATEUR") {
                echo '
                <li>
                    <a href="#GestionUtilisateurs" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-wrench" aria-hidden="true"></i> Gestion Utilisateurs</a>
                    <ul class="collapse list-unstyled" id="GestionUtilisateurs">
                        <!-- <li>
                            <a href="tout_les_admin.php">Tout Les Administrateur</a>
                        </li> -->
                        <li>
                            <a href="tout_les_utilisateur.php"><i class="fa fa-users" aria-hidden="true"></i> Tout Les Utilisateurs</a>
                        </li>
                        <li>
                            <a href="ajouter_utilisateur.php"><i class="fa fa-user-plus" aria-hidden="true"></i> Nouvel Utilisateur</a>
                        </li>
                        <!-- <li>
                            <a href="ajouter_admin.php">Nouvel Administrateur</a>
                        </li> -->
                    </ul>
                </li>
                ';
            }
        ?>
        <!-- <li>
            <a href="#GestionClients" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-wrench" aria-hidden="true"></i> Gestion Clients</a>
            <ul class="collapse list-unstyled" id="GestionClients">
                <li>
                    <a href="tout_les_clients.php"><i class="fa fa-users" aria-hidden="true"></i> Tout Les Clients</a>
                </li>
                <li>
                    <a href="ajouter_client.php"><i class="fa fa-user-plus" aria-hidden="true"></i> Nouvel Client</a>
                </li>
            </ul>
        </li> -->
        <!-- <li>
            <a href="#">Contacts</a>
        </li> -->
    </ul>
</nav>