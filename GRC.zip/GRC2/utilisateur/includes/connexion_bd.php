<?php  
	$nom_du_server = "localhost";
	$nom_de_la_base = "grc2";
	$nom_d_utilisateur = "root";
	$mot_de_passe = "";

	$connexion = mysqli_connect($nom_du_server, $nom_d_utilisateur, $mot_de_passe, $nom_de_la_base);

    if ($connexion) {
    	
    }
    else
    	die('Connexion Echouer' . mysqli_error($connexion));
?>