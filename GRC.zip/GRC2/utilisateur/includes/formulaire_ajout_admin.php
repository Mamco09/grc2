
                            <div class="form-group row">
                                <label for="Prenom" class="col-sm-2 col-form-label">Prenom</label>
                                <div class="col-sm-10">
                                  <input type="text" size="40" maxlength="40" class="form-control" id="Prenom" placeholder="Prenom..." name="prenom" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="Nom" class="col-sm-2 col-form-label">Nom</label>
                                <div class="col-sm-10">
                                  <input type="text" size="40" maxlength="40" class="form-control" id="Nom" placeholder="Nom..." name="nom" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="Tel" class="col-sm-2 col-form-label">Tel</label>
                                <div class="col-sm-10">
                                  <input type="text" size="8" maxlength="8" class="form-control" id="Tel" placeholder="Tel..." name="tel" required>
                                </div>
                            </div>
                            <label class="col-sm-2 col-form-label">Genre</label>
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" name="genre" id="M" value="M" checked>
                              <label class="form-check-label" for="M">M</label>
                            </div>
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" name="genre" id="F" value="F" >
                              <label class="form-check-label" for="F">F</label>
                            </div>
                            <div class="form-group row">
                                <label for="DateNaiss" class="col-sm-2 col-form-label">Date Naiss</label>
                                <div class="col-sm-10">
                                  <input type="date" class="form-control" id="DateNaiss" placeholder="Identifiant..." name="date" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="Identifiant" class="col-sm-2 col-form-label">Identifiant</label>
                                <div class="col-sm-10">
                                  <input type="text" size="40" maxlength="40" class="form-control" id="Identifiant" placeholder="Identifiant..." name="identifiant" required>
                                </div>
                            </div>
                            <!-- mot de passe -->
                            <div class="form-group row">
                                <label for="MotDePasse" class="col-sm-2 col-form-label">Mot de passe</label>
                                <div class="col-sm-10">
                                  <input type="password" size="40" maxlength="40"  class="form-control" id="MotDePasse" placeholder="Mot de passe..." name="mdp" required>
                                </div>
                            </div>
                            <!-- ///mot de passe -->
                            <hr>
                            <div class="form-group row">
                                <div class="col-sm-10">
                                  <!-- Button affichant le modal -->
                                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#confirmation">
                                    Ajouter
                                  </button>

                                  <!-- Modal -->
                                  <div class="modal fade" id="confirmation" tabindex="-1" role="dialog" aria-labelledby="confirmation" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                      <div class="modal-content">
                                        <div class="modal-header">
                                          <!-- titre du modal -->
                                          <h5 class="modal-title" id="confirmation">Confirmation</h5>
                                          <!-- button de close du modal -->
                                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                          </button>
                                        </div>
                                        <!-- message du modal -->
                                        <div class="modal-body">
                                          <p>Etes vous sure ?</p>
                                        </div>
                                        <!-- ///message du modal -->
                                        <!-- les deux boutton de confirmation -->
                                        <div class="modal-footer">
                                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Annulé</button>
                                          <button type="submit" class="btn btn-primary" name="submit">Comfirmer</button>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <!-- ///Modal -->
                                </div>
                            </div>
                       