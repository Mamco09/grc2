<?php
		function space(){
			echo "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp";
		}

	function ExecuterRequetMisAJour($requet)
	{
		/*
		* Fonction d'execution de requet pour les mis a jour
		* @param string $requet
		* @return bool True ou False
		*/
		$nom_du_server = "localhost";
		$nom_de_la_base = "grc2";
		$nom_d_utilisateur = "root";
		$mot_de_passe = "";
		$tab2 = [];

		$connexion = mysqli_connect($nom_du_server, $nom_d_utilisateur, $mot_de_passe, $nom_de_la_base);

		$resultat = mysqli_query($connexion,$requet.";");
		if (!$resultat) 
		{
			return False;
		}
		return True;
	}

	function AfficheMessage(){
		/*
		* Fonction d'execution de requet pour les mis a jour
		* @param str : recoit $_GET['msg'] 
		* @return array : alert(success) ou alert(danger)
		*/
	    if (isset($_GET['msg'])) {
	        $msg = $_GET['msg'];
	        if ($msg == "op_re") {
	           echo '
	                <div class="alert alert-success alert-dismissible fade show" role="alert">
	                  <strong><i class="fa fa-check"></i> Operation Reussie!</strong>
	                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
	                    <span aria-hidden="true">&times;</span>
	                  </button>
	                </div>
	           ';
	        }elseif ($msg == "op_ec") {
	        	echo '
	        	     <div class="alert alert-danger alert-dismissible fade show" role="alert">
	        	       <strong>Operation Echouer!</strong>
	        	       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
	        	         <span aria-hidden="true">&times;</span>
	        	       </button>
	        	     </div>
	        	';
			}
			elseif($msg == "bienvenu"){
				echo '
				<div class="alert alert-info alert-dismissible fade show" role="alert">
					<strong>Binvenu '. $_SESSION["nom_complet"] . '</strong>
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					</button>
			  	</div>
				';
			}
			elseif($msg == "0020"){
				echo '
				<div class="alert alert-warning alert-dismissible fade show" role="alert">
					<strong>Désole Client Innexistant !</strong>
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					</button>
			  	</div>
				';
			}
	    }
	}

	function ExecuterRequetPlusieurResultat($requet)
	{
		/*
		* Fonction d'execution de requet pour la recuperation de donné (resultat : plusieur table)
		* @param str : $requet (SQL requet)
		* @return array : $tab2(associative multidimension --> $tab2[index][[$key][value]]) ou [] --> (vide)
		*/
		$nom_du_server = "localhost";
		$nom_de_la_base = "grc2";
		$nom_d_utilisateur = "root";
		$mot_de_passe = "";
		$index = 0;
		$tab2 = [];
		$connexion = mysqli_connect($nom_du_server, $nom_d_utilisateur, $mot_de_passe, $nom_de_la_base);

		$resultat = mysqli_query($connexion,$requet.";");
		if ($resultat) 
		{
			if (mysqli_num_rows($resultat) == 0) {
				return [];
			}
			while ($tab = mysqli_fetch_assoc($resultat)) 
			{
				foreach ($tab as $key => $value) 
				{
					$tab2["$index"] ["$key"] = $value; 
				}
				$index++;
			}
		}
		return $tab2;
	}

	function ExecuterRequetRecuperation($requet)
	{
		/*
		* Fonction d'execution de requet pour la recuperation de donné (resultat : 1 table)
		* @param str : $requet (SQL requet)
		* @return array : $tab(associative multidimension --> $tab[$key][value]) ou [] --> (vide)
		*/
		$nom_du_server = "localhost";
		$nom_de_la_base = "grc2";
		$nom_d_utilisateur = "root";
		$mot_de_passe = "";
		$tab2 = [];

		$connexion = mysqli_connect($nom_du_server, $nom_d_utilisateur, $mot_de_passe, $nom_de_la_base);

		$resultat = mysqli_query($connexion,$requet.";");
		if ($resultat) 
		{
			while ($tab = mysqli_fetch_assoc($resultat)) 
			{
				foreach ($tab as $key => $value) 
				{
					$tab2["$key"] = $value; 
				}
			}
		}
		return $tab2;
	}

	function GetGenreForm($genre){
		/*
		* Fonction de recuperaration du formulaire de genre
		* @param  : $genre (Str)
		* @return : NULL
		*/
		if ($genre == "M") {
			echo'
				<div class="form-check form-check-inline">
				  <input class="form-check-input" type="radio" name="genre" id="M" value="M" checked>
				  <label class="form-check-label" for="M">M</label>
				</div>
				<div class="form-check form-check-inline">
				  <input class="form-check-input" type="radio" name="genre" id="F" value="F" >
				  <label class="form-check-label" for="F">F</label>
				</div>
			';
		}
		else{
			echo'
				<div class="form-check form-check-inline">
				  <input class="form-check-input" type="radio" name="genre" id="M" value="M" >
				  <label class="form-check-label" for="M">M</label>
				</div>
				<div class="form-check form-check-inline">
				  <input class="form-check-input" type="radio" name="genre" id="F" value="F" checked>
				  <label class="form-check-label" for="F">F</label>
				</div>
			';
		}
	}

	function get_select_agence($requet, $value)
	{
		$resultat1 = ExecuterRequetPlusieurResultat($requet);
		for ($i = 0; $i < count($resultat1); $i++) {
			if ($resultat1[$i]['ID_AG'] == $value) {
				echo "
						<option value='{$resultat1[$i]['ID_AG']}'>{$resultat1[$i]['NOM_AG']}</option>
					";
			}
		}
		$resultat2 = ExecuterRequetPlusieurResultat($requet);
		for ($i = 0; $i < count($resultat2); $i++) {
			if ($resultat2[$i]['ID_AG'] != $value) {
				echo "
						<option value='{$resultat2[$i]['ID_AG']}'>{$resultat2[$i]['NOM_AG']}</option>
					";
			}
		}
	}

	function get_select_profil($requet, $value)
	{
		$resultat1 = ExecuterRequetPlusieurResultat($requet);
		for ($i = 0; $i < count($resultat1); $i++) {
			if ($resultat1[$i]['ID_PROFIL'] == $value) {
				echo "
							<option value='{$resultat1[$i]['ID_PROFIL']}'>{$resultat1[$i]['NOM_PROFIL']}</option>
						";
			}
		}
		$resultat2 = ExecuterRequetPlusieurResultat($requet);
		for ($i = 0; $i < count($resultat2); $i++) {
			if ($resultat2[$i]['ID_PROFIL'] != $value) {
				echo "
							<option value='{$resultat2[$i]['ID_PROFIL']}'>{$resultat2[$i]['NOM_PROFIL']}</option>
						";
			}
		}
	}


	function get_select_gerant($requet, $value)
	{
		$resultat1 = ExecuterRequetPlusieurResultat($requet);
		for ($i = 0; $i < count($resultat1); $i++) {
			if ($resultat1[$i]['ID_G'] == $value) {
				echo "
							<option value='{$resultat1[$i]['ID_G']}'>{$resultat1[$i]['PRENOM_G']} {$resultat1[$i]['NOM_G']}({$resultat1[$i]['ID_G']})</option>
						";
			}
		}
		$resultat2 = ExecuterRequetPlusieurResultat($requet);
		for ($i = 0; $i < count($resultat2); $i++) {
			if ($resultat2[$i]['ID_G'] != $value) {
				echo "
							<option value='{$resultat2[$i]['ID_G']}'>{$resultat2[$i]['PRENOM_G']} {$resultat2[$i]['NOM_G']}({$resultat2[$i]['ID_G']})</option>
						";
			}
		}
	}


	function get_gerant($requet)
	{
		$resultat1 = ExecuterRequetPlusieurResultat($requet);
		for ($i = 0; $i < count($resultat1); $i++) {
			
			echo "
				<option value='{$resultat1[$i]['ID_G']}'>{$resultat1[$i]['PRENOM_G']} {$resultat1[$i]['NOM_G']}({$resultat1[$i]['ID_G']})</option>
				";
			
		}
	}

	function get_rec_color($value)
	{
		if ($value == "TRES URGENT") {
			echo "bg-danger";
		}
		elseif ($value == "URGENT") {
			echo "bg-warning";
		}
		elseif ($value == "PAS TRES URGENT") {
			echo "bg-info";
		}
		elseif ($value == "") {
			echo "bg-success";
		}
	}

	function timeAgo($timestamp){
	    $datetime1=new DateTime("now");
	    $datetime2=date_create($timestamp);
	    $diff=date_diff($datetime1, $datetime2);
	    $timemsg='';
	    if($diff->y > 0){
	        $timemsg = $diff->y .' anne'. ($diff->y > 1?"s":'');

	    }
	    else if($diff->m > 0){
	     $timemsg = $diff->m . ' mois';
	    }
	    else if($diff->d > 0){
	     $timemsg = $diff->d .' jour'. ($diff->d > 1?"s":'');
	    }
	    else if($diff->h > 0){
	     $timemsg = $diff->h .' heure'.($diff->h > 1 ? "s":'');
	    }
	    else if($diff->i > 0){
	     $timemsg = $diff->i .' minute'. ($diff->i > 1?"s":'');
	    }
	    else if($diff->s > 0){
	     $timemsg = $diff->s .' seconde'. ($diff->s > 1?"s":'');
	    }

	$timemsg = "il y'a ".$timemsg;
	return $timemsg;
	}


	
	?>
	