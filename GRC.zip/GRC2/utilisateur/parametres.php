<?php include_once 'includes/head.php'; ?>

<body>
<?php $_SESSION['page_actuel'] = basename(__FILE__); ?>
    <div class="wrapper">
        <!-- Sidebar  -->
        <?php include_once 'includes/sidebar.php'; ?>

        <!-- Page Content  -->
        <div id="content">
            <!-- navbar  -->
            <?php include_once 'includes/navbar.php'; ?>

            <!-- container -->
            <div class="container">
                <!-- row -->
                <div class="row">
                    <!-- div col 12 -->
                    <div class="col-md-12">
                        <?php AfficheMessage(); ?>
                        <div class="header">
                            <h1>Utilisateur: <?php echo $_SESSION['nom_complet']; ?></h1>
                        </div>
                        <!-- ////div col 12 -->
                    </div>

                    <!-- div line -->
                    <div class="line"></div>

                    <!-- div col 12 -->
                    <div class="col-md-12">
                        <h2>Parametres</h2>
                        <!-- liste de parametres -->
                        <ul class="list-unstyled">
                            <li><i class=""></i><a href="gestion_agence.php"><i class="fa fa-cog" aria-hidden="true"></i> Gestion Agence</a></li>
                            <li><i class=""></i><a href="gestion_type.php"><i class="fa fa-cog" aria-hidden="true"></i> Gestion Type</a></li>
                            <!-- ////liste de parametres -->
                        </ul>
                        <!-- ////div col 12 -->
                    </div>
                    <!-- ////row -->
                </div>
                <!-- ////container -->
            </div>
            <!-- Page Content  -->
        </div>
    </div>

    <div class="overlay"></div>

    <?php include_once 'includes/scripts.php'; ?>
</body>

</html>