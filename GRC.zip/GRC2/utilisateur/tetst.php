<?php  
	function timeAgo($timestamp){
	    $datetime1=new DateTime("now");
	    $datetime2=date_create($timestamp);
	    $diff=date_diff($datetime1, $datetime2);
	    $timemsg='';
	    if($diff->y > 0){
	        $timemsg = $diff->y .' anne'. ($diff->y > 1?"s":'');

	    }
	    else if($diff->m > 0){
	     $timemsg = $diff->m . ' mois';
	    }
	    else if($diff->d > 0){
	     $timemsg = $diff->d .' jour'. ($diff->d > 1?"s":'');
	    }
	    else if($diff->h > 0){
	     $timemsg = $diff->h .' heure'.($diff->h > 1 ? "s":'');
	    }
	    else if($diff->i > 0){
	     $timemsg = $diff->i .' minute'. ($diff->i > 1?"s":'');
	    }
	    else if($diff->s > 0){
	     $timemsg = $diff->s .' seconde'. ($diff->s > 1?"s":'');
	    }

	$timemsg = "il y'a ".$timemsg;
	return $timemsg;
	}

	echo timeAgo('2019-07-01 00:00:00');
?>