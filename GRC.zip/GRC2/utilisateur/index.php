<?php
    // inclusion de la head  
    include_once 'includes/head.php';
?>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<body>
    <!-- div avec la class wrapper -->
<?php $_SESSION['page_actuel'] = basename(__FILE__); ?>
    <div class="wrapper">
        <!-- Sidebar  -->
        <?php include_once 'includes/sidebar.php'; ?>

        <!-- contenu1 de la page -->
        <div id="content">

            <!-- bar de navigation -->
            <?php include_once 'includes/navbar.php'; ?>

            <!-- contenu2 de la page -->
            <div class="container">

                <!-- row -->
                <div class="row">
                    <!-- div de 12 colonnes -->
                    <div class="col-md-12">

                        <?php
                            // fonction affichant les message d'erreur 
                            AfficheMessage(); 
                        ?>
                        <!-- header -->
                        <div class="header">
                            <h1>Bienvenu <?php echo $_SESSION['nom_complet']; ?></h1>
                        <!-- fin de la header -->
                        </div>

                        <div class="line"></div>

                                        <!-- /.row -->
                                        
                        <?php  
                            if ($_SESSION['profil'] == "ADMINISTRATEUR") {
                                include_once 'includes/admin_stats.php';
                            }
                        ?>

                <!-- /row -->    
                </div>

            <!-- fin du contenu2 de la page -->
            </div>
        <!-- fin du contenu1 de la page -->
        </div>
    <!-- fin de la div avec la class wrapper -->  
    </div>

    <div class="overlay"></div>

    <?php include_once 'includes/scripts.php';?>
</body>

</html>
