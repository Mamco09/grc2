<?php
  // inclusion de la head
  include_once 'includes/head.php';
  // redireition de la page actuel 
  $_SESSION['page_actuel'] = "tout_les_clients";
?>

<body>

  <div class="wrapper">
    <!-- Sidebar  -->
    <?php include_once 'includes/sidebar.php';?>

    <!-- Page Content  -->
    <div id="content">

      <!-- navbar  -->
      <?php include_once 'includes/navbar.php';?>

      <!-- container -->
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <?php
              // fonction affichant les message d'erreur
              AfficheMessage();
            ?>
            <!-- header -->
            <div class="header">
              <nav class="navbar navbar-light bg-light pull-right">

                <h1>Tout Les Clients</h1>
                <form class="form-inline ">
                  <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                  <button class="btn btn-outline-secondary my-2 my-sm-0" type="submit">Search</button>
                </form>
              </nav>
              <?php
              // requet de selection de les utilisateurs simple
              $requet = "SELECT * FROM client";

              $resultat_client = ExecuterRequetPlusieurResultat($requet);

              $nomre_de_resultat_client = count($resultat_client);
              ?>
            </div>
            <!-- ////header -->
          </div>

          <hr>
          <!-- div de 12 colone  -->
          <div class="col-md-12 ml-auto mr-auto">
            <h2>Clients</h2>
            <!-- tableau -->
            <table class="table">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Nom Complet</th>
                  <th scope="col">Genre</th>
                  <th scope="col">Tel</th>
                  <th scope="col"></th>
                  <th scope="col"></th>
                  <th scope="col"></th>
                </tr>
              </thead>
              <tbody>
                <?php
                  // cas ou le resultat est vide 
                  if ($nomre_de_resultat_client == 0) 
                  {
                    // affichage du  message Aucun resultat
                    echo "
                        <tr>
                        <th colspan='4'><center>Aucun Client</center></th>
                        </tr>
                        ";
                  } 
                  else 
                  {
                    for ($i = 0; $i < $nomre_de_resultat_client; $i++) 
                    {
                      // variable comptant les ligne du taleau a afficher
                      $line = $i + 1;
                          // arret du script pour afficher du html
                ?>        
                  <!-- tr -->
                  <tr>
                    <th scope='row'><?php echo $line; ?></th>
                    <td><?php echo $resultat_client[$i]['PRENOM_CLI']. " " .$resultat_client[$i]['NOM_CLI']; //nom complet de l'utilisateur?></td>
                    <td><?php echo $resultat_client[$i]['GENRE_CLI']; // genre de l'utilisateur?></td>
                    <td><?php echo $resultat_client[$i]['TEL_CLI']; // elephone de l'utilisateur?></td>
                    <td>
                        <a href='' data-toggle='modal' data-target='.bd-example-modal-lg<?php echo $i; //la variable i differentiant les utilisateur?>'>
                            <i class='fas fa-info'></i>
                        </a>
                    </td>
                    <td>
                      <a href='mis_a_jour_client.php?id=<?php echo $resultat_client[$i]["ID_CLI"]; // identifiant numerique de l'utilisateur envoyer vers mis_a_jour_profil.php (Get method)?>'>
                        <i class='fas fa-edit'></i>
                      </a>
                    </td>
                    <td><a href='' data-toggle='modal' data-target='#exampleModal<?php echo $i; ?>'><i class='fas fa-trash'></i></a></td>
                  <!-- ////tr -->
                  </tr>
                  <!-- infos modal -->
                  <div class='modal fade bd-example-modal-lg<?php echo $i; ?>' tabindex='-1' role='dialog' aria-labelledby='myLargeModalLabel' aria-hidden='true'>
                      <div class='modal-dialog modal-lg'>

                          <div class='modal-content'>
                              <!-- header infos model -->
                              <div class='modal-header'>
                                  <h5 class='modal-title'>Informations Sur <?php echo $resultat_client[$i]["PRENOM_CLI"]." ".$resultat_client[$i]["NOM_CLI"] // nom complet de l'utilisateur?></h5>
                                  <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                                    <span aria-hidden='true'>&times;</span>
                                  </button>
                              <!-- ////header infos model -->
                              </div>
                              <!-- list-group -->
                              <ul class='list-group'>
                                <li class='list-group-item'>Prenom: <?php echo $resultat_client[$i]["PRENOM_CLI"];?></li>
                                <li class='list-group-item'>Nom   : <?php echo $resultat_client[$i]["NOM_CLI"];?></li>
                                <li class='list-group-item'>Genre : <?php echo $resultat_client[$i]["GENRE_CLI"];?></li>
                                <li class='list-group-item'>Tel   : <?php echo $resultat_client[$i]["TEL_CLI"];?></li>
                                <li class='list-group-item'>Date Naiss : <?php echo $resultat_client[$i]["DATE_NAISS_CLI"];?></li>
                                <li class='list-group-item'>Num compte   : <?php echo $resultat_client[$i]["NUM_COMPT_CLI"];?></li>
                              <!-- ////list-group -->
                              </ul>

                          </div>
                      </div>
                  <!-- ////infos modal -->
                  </div>

                  <!-- Supprimer Modal -->
                  <div class='modal fade' id='exampleModal<?php echo $i; ?>' tabindex='-1' role='dialog' aria-labelledby='exampleModal<?php echo $i; ?>Label' aria-hidden='true'>
                    <div class='modal-dialog' role='document'>
                      <div class='modal-content'>
                        <!-- header supprimer modal -->
                        <div class='modal-header'>
                          <h5 class='modal-title' id='exampleModal<?php echo $i; ?>Label'>Confirmation</h5>
                          <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                            <span aria-hidden='true'>&times;</span>
                          </button>
                        <!-- ////header supprimer modal -->
                        </div>
                        <div class='modal-body'>
                          <b>Supprimer <?php echo $resultat_client[$i]['PRENOM_CLI']." ".$resultat_client[$i]['NOM_CLI']; ?>echo </b>
                          <p>Etes vous sure ?</p>
                        </div>
                        <div class='modal-footer'>
                          <button type='button' class='btn btn-secondary' data-dismiss='modal'>Annulé</button>
                          <a href='scripts/script_supprimer_client.php?id=<?php $resultat_client[$i]['ID_CLI']; ?>' class='btn btn-primary'>Comfirmer</a>
                        </div>
                      </div>
                    </div>
                  <!-- ////Supprimer Modal -->
                  </div>
                <?php 
                    // reprise du script pour reprendre la oucle       
                    }
                  }
                ?>
              </tbody>
            <!-- ////tableau -->
            </table>
          <!-- ////div de 12 colone  -->
          </div>
        </div>
        <!-- ///container -->
      </div>
    </div>
  </div>

  <div class="overlay"></div>
  <?php
  include_once 'includes/scripts.php';
  ?>
</body>

</html>