<?php include_once 'includes/head.php'; ?>

<body>
<?php $_SESSION['page_actuel'] = basename(__FILE__); ?>
    <div class="wrapper">
        <!-- Sidebar  -->
        <?php include_once 'includes/sidebar.php'; ?>

        <!-- Page Content  -->
        <div id="content">
            <!-- navbar  -->
            <?php include_once 'includes/navbar.php'; ?>
            <!-- container -->
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="header">
                            <h1>Ajouter Utilisateur<h1>
                        </div>
                    </div>
                    <div class="line"></div>
                    <div class="col-md-12">
                        <!-- form start -->
                      <form action="scripts/ajouter_utilisateur_script.php" method="POST">
                            <?php include_once 'includes/formulaire_ajout.php';?>
                      </form>
                      <!-- ///form end -->
                    </div>
                </div>
            </div>
            <!-- ///container -->
        </div>
    </div>

    <div class="overlay"></div>

    <?php include_once 'includes/scripts.php';?>
</body>

</html>