<?php
    // inclusion de la head
    include_once 'includes/head.php';
    // redireition de la page actuel 
    $_SESSION['page_actuel'] = "";
?>

<body>
<?php $_SESSION['page_actuel'] = basename(__FILE__); ?>
    <div class="wrapper">
        <!-- Sidebar  -->
        <?php include_once 'includes/sidebar.php'; ?>

        <!-- Page Content  -->
        <div id="content">
            <!-- navbar  -->
            <?php include_once 'includes/navbar.php'; ?>
            <!-- container -->
            <div class="container">
                <div class="row">
                    <!-- div col 12 -->
                    <div class="col-md-12">
                        <div class="header">
                            <h1>Mis a Jour de Profil<h1>
                                    <?php
                                    if (isset($_GET['id'])) {
                                        // recuperation de id envoyer par method get
                                        $id = $_GET['id'];
                                        // requet de recuperation 
                                        $requet = "SELECT * FROM utilisateur INNER JOIN profil INNER JOIN agence WHERE utilisateur.ID_PROFIL = profil.ID_PROFIL AND utilisateur.ID_AG = agence.ID_AG AND ID_U = {$id}";
                                        $resultat = ExecuterRequetRecuperation($requet);
                                    }
                                    ?>
                        </div>
                    <!-- ////div col 12 -->
                    </div>

                    <!-- div line -->
                    <div class="line"></div>

                    <!-- div col 12 -->
                    <div class="col-md-12">
                        <!-- form start -->
                        <form action="scripts/script_mis_a_jour_profil.php?id=<?php echo $resultat['ID_U']; //id de l'utilisateur?>" method="POST">
                            <!-- div > label > input -->    
                            <div class="form-group row">
                                <label for="Prenom" class="col-sm-2 col-form-label">Prenom</label>
                                <div class="col-sm-10">
                                    <input type="text" size="40" maxlength="40" class="form-control" id="Prenom" placeholder="Prenom..." value="<?php echo $resultat['PRENOM_U']; // prenom de l'utilisateur?>" name="prenom" required>
                                </div>
                            <!-- ////div > label > input -->
                            </div>

                            <!-- div > label > input -->
                            <div class="form-group row">
                                <label for="Nom" class="col-sm-2 col-form-label">Nom</label>
                                <div class="col-sm-10">
                                    <input type="text" size="40" maxlength="40" class="form-control" id="Nom" placeholder="Nom..." value="<?php echo $resultat['NOM_U']; // nom de l'utilisateur?>" name="nom" required>
                                </div>
                            <!-- ////div > label > input -->
                            </div>

                            <!-- div > label > input -->
                            <div class="form-group row">
                                <label for="Tel" class="col-sm-2 col-form-label">Tel</label>
                                <div class="col-sm-10">
                                    <input type="text" size="8" maxlength="8" class="form-control" id="Tel" placeholder="Tel..." value="<?php echo $resultat['TEL_U']; // tel de l'utilisateur?>" name="tel" required>
                                </div>
                            <!-- ////div > label > input -->
                            </div>

                        
                            <label class="col-sm-2 col-form-label">Genre</label>
                            <?php GetGenreForm($resultat['GENRE_U']); // pour plus d'infos --> utilisateur/fonctions.php?>
                            
                            <!-- div > label > input -->
                            <div class="form-group row">
                                <label for="Tel" class="col-sm-2 col-form-label">Tel</label>
                                <div class="col-sm-10">
                                    <input type="date" class="form-control" id="Tel" placeholder="Tel..." value="<?php echo $resultat['DATE_NAISS_U']; ?>" name="date" required>
                                </div>
                            <!-- ////div > label > input -->
                            </div>

                            <!-- div > label > input -->
                            <div class="form-group row">
                                <label for="Identifiant" class="col-sm-2 col-form-label">Identifiant</label>
                                <div class="col-sm-10">
                                    <input type="text" size="40" maxlength="40" class="form-control" id="Identifiant" placeholder="Identifiant..." value="<?php echo $resultat['IDENTIFIANT_U']; ?>" name="identifiant" required>
                                </div>
                            <!-- ////div > label > input -->
                            </div>

                            <!-- div > label > input -->
                            <div class="form-group row">
                                <label for="MotDePasse" class="col-sm-2 col-form-label">Mot de passe</label>
                                <div class="col-sm-10">
                                    <input type="password" size="40" maxlength="40" class="form-control" id="MotDePasse" placeholder="Mot de passe..." value="<?php echo $resultat['MDP_U']; ?>" name="mdp" required>
                                </div>
                            <!-- ////div > label > input -->
                            </div>

                            <!-- div > label > select -->
                            <div class="form-group row">
                                <label for="MotDePasse" class="col-sm-2 col-form-label">Agence</label>
                                <div class="col-sm-10">
                                    <select name="agence" id="" class="form-control">
                                        <?php
                                        $requet1 = "SELECT * FROM agence";
                                        $value1 = $resultat['ID_AG'];
                                        get_select_agence($requet1, $value1);
                                        ?>
                                    </select>
                                </div>
                            <!-- ////div > label > select -->
                            </div>

                            <!-- div > label > select -->
                            <div class="form-group row">
                                <label for="MotDePasse" class="col-sm-2 col-form-label">Profil</label>
                                <div class="col-sm-10">
                                    <select name="profil" id="" class="form-control">
                                        <?php
                                        $requet2 = "SELECT * FROM profil";
                                        $value2 = $resultat['ID_PROFIL'];
                                        get_select_profil($requet2, $value2);
                                        ?>
                                    </select>
                                </div>
                            <!-- ////div > label > select -->
                            </div>
                            <!-- dive line -->
                            <div class="line"></div>

                            <!-- row -->
                            <div class="form-group row">
                                <div class="col-sm-10">
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                                        Mettre a jour le profil
                                    </button>

                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <!-- content -->
                                            <div class="modal-content">
                                                <!-- modal-header -->
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Confirmation</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                <!-- ////modal-header -->
                                                </div>

                                                <div class="modal-body">
                                                    <p>Etes vous sure ?</p>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annulé</button>
                                                    <button type="submit" class="btn btn-primary" name="mod_user">Comfirmer</button>
                                                </div>
                                            <!-- ////content -->
                                            </div>
                                        </div>
                                    <!-- ////Modal -->
                                    </div>
                                </div>
                            <!-- ////row -->
                            </div>

                        </form>
                    <!-- ////div col 12 -->
                    </div>
                </div>
            </div>
            <!-- ///container -->
        </div>
    </div>

    <div class="overlay"></div>

    <?php include_once 'includes/scripts.php'; ?>
</body>

</html>