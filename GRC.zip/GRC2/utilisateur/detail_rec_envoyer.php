<?php
// inclusion de la head
include_once 'includes/head.php';
// redireition de la page actuel 
?>

<body>
<?php $_SESSION['page_actuel'] = basename(__FILE__); ?>
    <div class="wrapper">
        <!-- Sidebar  -->
        <?php include_once 'includes/sidebar.php'; ?>

        <!-- Page Content  -->
        <div id="content">

            <!-- navbar  -->
            <?php include_once 'includes/navbar.php'; ?>

            <!-- container -->
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <?php
                        // fonction affichant les message d'erreur
                        AfficheMessage();
                        ?>
                        <!-- header -->
                        <div class="header">
                            <nav class="navbar navbar-light bg-light pull-right">

                                <h1>Reclamation Repondues</h1>
                                <?php   include_once 'includes/search.php' ?>
                            </nav>
                            <?php
                            // requet de selection de les utilisateurs simple
                            $requet = "SELECT * 
                            FROM reclamation 
                            INNER JOIN utilisateur
                            INNER JOIN type 
                            INNER JOIN etat 
                            INNER JOIN priorite 
                            INNER JOIN piece_jointe 
                            INNER JOIN agence 
                            INNER JOIN profil 
                            WHERE reclamation.ID_U = utilisateur.ID_U 
                            AND reclamation.ID_TYPE = type.ID_TYPE 
                            AND reclamation.ID_ETAT = etat.ID_ETAT 
                            AND reclamation.ID_PRI = priorite.ID_PRI 
                            AND reclamation.ID_PJ = piece_jointe.ID_PJ 
                            AND utilisateur.ID_AG = agence.ID_AG 
                            AND utilisateur.ID_PROFIL = profil.ID_PROFIL
                            ORDER BY reclamation.DATE_REC DESC";

                            $resultat_rec_env = ExecuterRequetPlusieurResultat($requet);

                            $nomre_de_resultat_rec_env = count($resultat_rec_env);
                            ?>
                        </div>
                        <!-- ////header -->
                    </div>

                    <hr>
                    <!-- div de 12 colone  -->
                    <div class="col-md-12 ml-auto mr-auto">
                        <h2>Mes Reclamations</h2>
                        <?php
                        // tesst si le resultat est vide
                        if ($nomre_de_resultat_rec_env == 0) 
                            { 
                                echo "<center>Aucune Reclamation</center>";
                            } 
                            else 
                            {
                                // cas ou le resultat !vide
                                for ($i = 0; $i < $nomre_de_resultat_rec_env; $i++) 
                                {
                                    
                        ?>


                        <?php include 'includes/reclamation.php'; ?>



                        <?php

                                    
                                }
                            }
                        ?>

                    </div>
                    <!-- ////div de 12 colone  -->
                </div>
            </div>
            <!-- ///container -->
        </div>
    </div>
    </div>

    <div class="overlay"></div>
    <?php
    include_once 'includes/scripts.php';
    ?>
</body>

</html>