<?php
    // inclusion de la head  
    include_once 'includes/head.php'; 
?>

<body>
    <?php $_SESSION['page_actuel'] = basename(__FILE__); ?>
    <!-- div avec la class wrapper -->

    <div class="wrapper">
        <!-- Sidebar  -->
        <?php include_once 'includes/sidebar.php'; ?>

        <!-- contenu1 de la page -->
        <div id="content">

            <!-- bar de navigation -->
            <?php include_once 'includes/navbar.php'; ?>

            <!-- contenu2 de la page -->
            <div class="container">

                <!-- row -->
                <div class="row">
                    <!-- div de 12 colonnes -->
                    <div class="col-md-12">

                        <?php
                            // fonction affichant les message d'erreur 
                            AfficheMessage(); 
                            $id_rec = "";
                            if ($_GET['id_rec']) 
                            {
                                $id_rec = $_GET['id_rec'];
                            }
                        ?>

                        <!-- header -->
                        <div class="header">
                            <h1>Reponses de la reclamation Numero <?php echo $id_rec; ?></h1>
                        <!-- fin de la header -->
                        </div>
                        <div class="line"></div>
                        <div>
                            <form action="scripts/script_reponse.php?id_rec=<?php echo $id_rec; ?>" method="POST" enctype="multipart/form-data">
                                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                  <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Reponse</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                          <span aria-hidden="true">&times;</span>
                                        </button>
                                      </div>
                                      <div class="modal-body">
                                        <form>
                                          <div class="custom-file">
                                                <label for="message-text" class="col-form-label">Piece Jointe :</label>
                                                <input type="file" name="document">
                                            </div>
                                          <div class="form-group">
                                            <label for="message-text" class="col-form-label">Reponse:</label>
                                            <textarea class="form-control" id="message-text" name="reponse" required></textarea>
                                          </div>
                                        </form>
                                      </div>
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annulé</button>
                                        <button type="submit" class="btn btn-primary" name="submit">Repondre</button>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                            </form>
                        </div>
                        <div class="line"></div>

                        <!-- list reponse -->
                        <?php  
                            
                                # code...
                            $requet = "SELECT * 
                            FROM reponse 
                            INNER JOIN utilisateur 
                            INNER JOIN reclamation 
                            INNER JOIN agence 
                            INNER JOIN piece_jointe 
                            WHERE reponse.ID_U = utilisateur.ID_U 
                            AND reponse.ID_REC = reclamation.ID_REC 
                            AND utilisateur.ID_AG = agence.ID_AG 
                            AND reponse.ID_PJ = piece_jointe.ID_PJ 
                            AND reclamation.ID_REC = {$id_rec}
                            ORDER BY reponse.DATE_REP DESC";

                            $resultat = ExecuterRequetPlusieurResultat($requet);

                                if ($resultat) 
                                {
                                    for ($i=0; $i < count($resultat); $i++) 
                                    { 
                                        # code...
                        ?>
<div class="list-group">
  
    <div class="d-flex w-100 justify-content-between">
        <!-- nom de l'emeteur de la reponse -->
        <h5 class="mb-1">
        <?php echo $resultat[$i]['PRENOM_U']." ".$resultat[$i]['NOM_U']; ?>
        </h5>
        <!-- date de la reponse -->  
        <small><?php echo timeAgo($resultat[$i]['DATE_REP']); ?></small>
    </div>
    <p class="mb-1"><?php echo $resultat[$i]['REP']; ?></p>
    <small class="mb-1">
        De l'agence &nbsp<?php echo $resultat[$i]['NOM_AG'];?>&nbsp Tel :  &nbsp<?php echo $resultat[$i]['TEL_U']; ?>&nbsp 
        <?php
            if ($resultat[$i]['ID_PJ'] != 1) 
            {
                $requet2 = "SELECT * FROM piece_jointe WHERE ID_PJ = {$resultat[$i]['ID_PJ']} AND ID_PJ = {$resultat[$i]['ID_PJ']}";
                $resultat2 = ExecuterRequetRecuperation($requet2);
                if ($resultat2) 
                {

                    echo "<a href='doc/{$resultat2['NOM_PJ']}' style='color:blue'></i>{$resultat2['NOM_PJ']} <i class='fas fa-download'></i></a>";
                }
            }
            else 
            {
                echo "<i class='fa fa-file' aria-hidden='true'></i> AUCUNE";
            }
        ?>
    </small>
    <small><a href="pull-right"  data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Repondre </a></small>
</div>
                                <hr>

                        <?php
                                    }
                                }

                        ?>
                              
                    <!-- fin de la div de 12 colonnes -->
                    </div>

                    <!-- ligne horizontal stiliser -->
                    <div class="line"></div>

                <!-- /row -->    
                </div>

            <!-- fin du contenu2 de la page -->
            </div>
        <!-- fin du contenu1 de la page -->
        </div>
    <!-- fin de la div avec la class wrapper -->  
    </div>

    <div class="overlay"></div>

    <?php include_once 'includes/scripts.php';?>
</body>

</html>
