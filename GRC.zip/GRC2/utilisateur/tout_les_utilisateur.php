<?php
  // inclusion de la head
  include_once 'includes/head.php';
  // redireition de la page actuel 
  $_SESSION['page_actuel'] = "tout_les_utilisateur";
?>

<body>

  <div class="wrapper">
    <!-- Sidebar  -->
    <?php include_once 'includes/sidebar.php';?>

    <!-- Page Content  -->
    <div id="content">

      <!-- navbar  -->
      <?php include_once 'includes/navbar.php';?>

      <!-- container -->
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <?php
              // fonction affichant les message d'erreur
              AfficheMessage();
            ?>
            <!-- header -->
            <div class="header">
              <nav class="navbar navbar-light bg-light pull-right">

                <h1>Tout Les Utilisateurs</h1>
                <form class="form-inline ">
                  <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                  <button class="btn btn-outline-secondary my-2 my-sm-0" type="submit">Search</button>
                </form>
              </nav>
              <?php
              // requet de selection de les utilisateurs simple
              $requet = "SELECT * FROM utilisateur INNER JOIN agence INNER JOIN profil WHERE utilisateur.ID_AG = agence.ID_AG AND utilisateur.ID_PROFIL = profil.ID_PROFIL";

              $resultat_utilisateur = ExecuterRequetPlusieurResultat($requet);

              $nomre_de_resultat_utilisateur = count($resultat_utilisateur);
              ?>
            </div>
            <!-- ////header -->
          </div>

          <hr>
          <!-- div de 12 colone  -->
          <div class="col-md-12 ml-auto mr-auto">
            <h2>Utilisateurs</h2>
            <!-- tableau -->
            <table class="table">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Nom Complet</th>
                  <th scope="col">Genre</th>
                  <th scope="col">Tel</th>
                  <th scope="col"></th>
                  <th scope="col"></th>
                  <th scope="col"></th>
                </tr>
              </thead>
              <tbody>
                <?php
                  // cas ou le resultat est vide 
                  if ($nomre_de_resultat_utilisateur == 0) 
                  {
                    // affichage du  message Aucun resultat
                    echo "
                        <tr>
                        <th colspan='4'><center>Aucun Utilisateur</center></th>
                        </tr>
                        ";
                  } 
                  else 
                  {
                    for ($i = 0; $i < $nomre_de_resultat_utilisateur; $i++) 
                    {
                      // variable comptant les ligne du taleau a afficher
                      $line = $i + 1;
                          // arret du script pour afficher du html
                ?>        
                  <!-- tr -->
                  <tr>
                    <th scope='row'><?php echo $line; ?></th>
                    <td><?php echo $resultat_utilisateur[$i]['PRENOM_U']. " " .$resultat_utilisateur[$i]['NOM_U']; //nom complet de l'utilisateur?></td>
                    <td><?php echo $resultat_utilisateur[$i]['GENRE_U']; // genre de l'utilisateur?></td>
                    <td><?php echo $resultat_utilisateur[$i]['TEL_U']; // elephone de l'utilisateur?></td>
                    <td>
                        <a href='' data-toggle='modal' data-target='.bd-example-modal-lg<?php echo $i; //la variable i differentiant les utilisateur?>'>
                            <i class='fas fa-info'></i>
                        </a>
                    </td>
                    <td>
                      <a href='mis_a_jour_profil.php?id=<?php echo $resultat_utilisateur[$i]["ID_U"]; // identifiant numerique de l'utilisateur envoyer vers mis_a_jour_profil.php (Get method)?>'>
                        <i class='fas fa-edit'></i>
                      </a>
                    </td>
                    <td><a href='' data-toggle='modal' data-target='#exampleModal<?php echo $i; ?>'><i class='fas fa-trash'></i></a></td>
                  <!-- ////tr -->
                  </tr>
                  <!-- infos modal -->
                  <div class='modal fade bd-example-modal-lg<?php echo $i; ?>' tabindex='-1' role='dialog' aria-labelledby='myLargeModalLabel' aria-hidden='true'>
                      <div class='modal-dialog modal-lg'>

                          <div class='modal-content'>
                              <!-- header infos model -->
                              <div class='modal-header'>
                                  <h5 class='modal-title'>Informations Sur <?php echo $resultat_utilisateur[$i]["PRENOM_U"]." ".$resultat_utilisateur[$i]["NOM_U"] // nom complet de l'utilisateur?></h5>
                                  <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                                    <span aria-hidden='true'>&times;</span>
                                  </button>
                              <!-- ////header infos model -->
                              </div>
                              <!-- list-group -->
                              <ul class='list-group'>
                                <li class='list-group-item'>Prenom: <?php echo $resultat_utilisateur[$i]["PRENOM_U"];?></li>
                                <li class='list-group-item'>Nom   : <?php echo $resultat_utilisateur[$i]["NOM_U"];?></li>
                                <li class='list-group-item'>Genre : <?php echo $resultat_utilisateur[$i]["GENRE_U"];?></li>
                                <li class='list-group-item'>Tel   : <?php echo $resultat_utilisateur[$i]["TEL_U"];?></li>
                                <li class='list-group-item'>Identifiant : <?php echo $resultat_utilisateur[$i]["IDENTIFIANT_U"];?></li>
                                <li class='list-group-item'>Agence : <?php echo $resultat_utilisateur[$i]["NOM_AG"];?></li>
                                <li class='list-group-item'>Date Naiss : <?php echo $resultat_utilisateur[$i]["DATE_NAISS_U"];?></li>
                                <li class='list-group-item'>Date Ajout : <?php echo $resultat_utilisateur[$i]["DATE_AJOUT_U"];?></li>
                                <li class='list-group-item'>Profil : <?php echo $resultat_utilisateur[$i]["NOM_PROFIL"];?></li>
                              <!-- ////list-group -->
                              </ul>

                          </div>
                      </div>
                  <!-- ////infos modal -->
                  </div>

                  <!-- Supprimer Modal -->
                  <div class='modal fade' id='exampleModal<?php echo $i; ?>' tabindex='-1' role='dialog' aria-labelledby='exampleModal<?php echo $i; ?>Label' aria-hidden='true'>
                    <div class='modal-dialog' role='document'>
                      <div class='modal-content'>
                        <!-- header supprimer modal -->
                        <div class='modal-header'>
                          <h5 class='modal-title' id='exampleModal<?php echo $i; ?>Label'>Confirmation</h5>
                          <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                            <span aria-hidden='true'>&times;</span>
                          </button>
                        <!-- ////header supprimer modal -->
                        </div>
                        <div class='modal-body'>
                          <b>Supprimer <?php echo $resultat_utilisateur[$i]['PRENOM_U']." ".$resultat_utilisateur[$i]['NOM_U']; ?>echo </b>
                          <p>Etes vous sure ?</p>
                        </div>
                        <div class='modal-footer'>
                          <button type='button' class='btn btn-secondary' data-dismiss='modal'>Annulé</button>
                          <a href='scripts/script_supprimer_utilisateur.php?id=<?php $resultat_utilisateur[$i]['ID_U']; ?>' class='btn btn-primary'>Comfirmer</a>
                        </div>
                      </div>
                    </div>
                  <!-- ////Supprimer Modal -->
                  </div>
                <?php 
                    // reprise du script pour reprendre la oucle       
                    }
                  }
                ?>
              </tbody>
            <!-- ////tableau -->
            </table>
          <!-- ////div de 12 colone  -->
          </div>
        </div>
        <!-- ///container -->
      </div>
    </div>
  </div>

  <div class="overlay"></div>
  <?php
  include_once 'includes/scripts.php';
  ?>
</body>

</html>