<?php
	session_destroy();
	if (isset($_POST['submit'])) 
	{
		// recuperation des donnees identifiant + mot de passe
		$identifiant = $_POST['identifiant'];
		$mdp = $_POST['mdp'];
		// connexion  la base
		include_once 'utilisateur/includes/connexion_bd.php';
		// premiere requet de verification des données envoyer
		echo $requet = "SELECT * FROM utilisateur INNER JOIN profil WHERE utilisateur.ID_PROFIL = profil.ID_PROFIL AND MDP_U = '{$mdp}' AND IDENTIFIANT_U = '{$identifiant}'";
		// resultat 
		$resultat = mysqli_query($connexion, $requet);
		// verification du resultat 
		if ($resultat) 
		{
			// cas ou le resultat  est vide
			if (mysqli_num_rows($resultat) == 0) 
			{
				// redirection vers index.php averc un message d'erreur (msg=erreur)
				header("Location: index.php?msg=erreur");
			}
			while ($row = mysqli_fetch_assoc($resultat)) 
			{
				// nouvel session utilisateur
				session_start();
				$_SESSION['nom_complet'] = $row['PRENOM_U'] . " " . $row['NOM_U']; // nom complet de l'utitulisateur 
				$_SESSION['nom'] = $row['NOM_U']; // nom de l'utitulisateur 
				$_SESSION['prenom'] = $row['PRENOM_U']; // prenom de l'utitulisateur 
				$_SESSION['identifiant'] = $row['IDENTIFIANT_U']; //identifiant de l'utilisateur courant
				$_SESSION['profil'] = $row['NOM_PROFIL']; // profil de l'utilisateur
				$_SESSION['id'] = $row['ID_U']; // identifiant numerique de l'utilisateur courant 
				$_SESSION['page_actuel'] = ""; // vide pour l'instant met prendra le nom du fichier qui est executer
				// redirection ver la page d'acceuil d'utilisateur avec message bienvenue
				header( "Location: utilisateur/index.php?msg=bienvenu");
				
			}
		}
		else{
			// arret de toute execution 
			die("Requet1 echouer " . mysqli_error($connexion));
		}
	}
?>